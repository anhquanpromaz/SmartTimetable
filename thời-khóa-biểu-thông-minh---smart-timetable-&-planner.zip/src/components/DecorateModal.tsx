import React, { useRef } from 'react';
import { X, Image as ImageIcon, Sparkles, Trash2, Smile, Type, Check } from 'lucide-react';
import { TimetableDecoration, TimetableSticker } from '../types/timetable';
import { THEMES, STICKER_LIBRARY } from '../constants/initialData';

interface DecorateModalProps {
  isOpen: boolean;
  onClose: () => void;
  decoration: TimetableDecoration;
  onUpdateDecoration: (decoration: TimetableDecoration) => void;
  onOpenDrawingModal: () => void;
}

export const DecorateModal: React.FC<DecorateModalProps> = ({
  isOpen,
  onClose,
  decoration,
  onUpdateDecoration,
  onOpenDrawingModal,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!isOpen) return null;

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 4 * 1024 * 1024) {
      alert('Kích thước ảnh quá lớn! Vui lòng chọn ảnh dưới 4MB để đảm bảo tốc độ.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      onUpdateDecoration({
        ...decoration,
        backgroundImage: result,
      });
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveImage = () => {
    onUpdateDecoration({
      ...decoration,
      backgroundImage: null,
    });
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleAddSticker = (emoji: string) => {
    const newSticker: TimetableSticker = {
      id: `stk_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      content: emoji,
      type: 'emoji',
      x: 10 + Math.random() * 70, // percentage
      y: 10 + Math.random() * 70,
      size: 28,
      rotation: Math.floor(Math.random() * 30) - 15,
    };

    onUpdateDecoration({
      ...decoration,
      stickers: [...(decoration.stickers || []), newSticker],
    });
  };

  const handleClearStickers = () => {
    if (confirm('Bạn có muốn gỡ bỏ tất cả sticker trang trí trên bảng không?')) {
      onUpdateDecoration({
        ...decoration,
        stickers: [],
      });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-200 my-8">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-600 text-white">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold">Trang Trí Thời Khóa Biểu</h2>
              <p className="text-xs text-white/80">Tải ảnh nền, chọn chủ đề, dán sticker và vẽ doodle sinh động</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-white/80 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {/* Quick Action: Draw on Timetable */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-rose-50 to-indigo-50 border border-indigo-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-1.5 font-bold text-slate-800 text-sm">
                <span>🎨 Vẽ trực tiếp lên thời khóa biểu</span>
                <span className="text-[11px] bg-rose-500 text-white font-medium px-2 py-0.5 rounded-full">
                  Mới
                </span>
              </div>
              <p className="text-xs text-slate-600 mt-0.5">
                Vẽ tự do bằng bút chì, bút dạ quang, tẩy và thêm ghi chú vẽ tay
              </p>
            </div>
            <button
              onClick={() => {
                onClose();
                onOpenDrawingModal();
              }}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors shrink-0 flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Mở Bảng Vẽ Ngay</span>
            </button>
          </div>

          {/* Title & Subtitle customization */}
          <div className="space-y-3">
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
              <Type className="w-3.5 h-3.5 text-indigo-500" />
              <span>Tiêu Đề &amp; Thông Tin Lớp Học</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-slate-500 block mb-1">Tiêu đề thời khóa biểu</label>
                <input
                  type="text"
                  value={decoration.title}
                  onChange={(e) => onUpdateDecoration({ ...decoration, title: e.target.value })}
                  placeholder="VD: Thời Khóa Biểu Năm Học Mới"
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="text-xs text-slate-500 block mb-1">Lớp / Học kỳ / Châm ngôn</label>
                <input
                  type="text"
                  value={decoration.subtitle}
                  onChange={(e) => onUpdateDecoration({ ...decoration, subtitle: e.target.value })}
                  placeholder="VD: Lớp 11A1 • Học Kỳ 1"
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>
          </div>

          {/* Theme Palette */}
          <div className="space-y-3">
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
              Chủ Đề Giao Diện (Theme)
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {THEMES.map((theme) => {
                const isActive = decoration.theme === theme.id;
                return (
                  <button
                    key={theme.id}
                    onClick={() => onUpdateDecoration({ ...decoration, theme: theme.id as any })}
                    className={`p-3 rounded-xl border text-left transition-all relative overflow-hidden flex flex-col justify-between h-20 ${
                      isActive
                        ? 'border-indigo-600 ring-2 ring-indigo-500/30 shadow-xs'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className={`absolute inset-0 bg-gradient-to-br ${theme.bgGradient} opacity-60`} />
                    <div className="relative z-10 flex items-center justify-between w-full">
                      <span className={`text-xs font-bold ${theme.isDark ? 'text-slate-800' : 'text-slate-800'}`}>
                        {theme.name}
                      </span>
                      {isActive && <Check className="w-4 h-4 text-indigo-600" />}
                    </div>
                    <div className="relative z-10 flex gap-1">
                      <span className="w-3.5 h-3.5 rounded-full bg-pink-400 border border-white" />
                      <span className="w-3.5 h-3.5 rounded-full bg-blue-400 border border-white" />
                      <span className="w-3.5 h-3.5 rounded-full bg-emerald-400 border border-white" />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Upload Custom Background Image */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <ImageIcon className="w-3.5 h-3.5 text-indigo-500" />
                <span>Tải Ảnh Nền Cho Thời Khóa Biểu</span>
              </label>
              {decoration.backgroundImage && (
                <button
                  onClick={handleRemoveImage}
                  className="text-xs text-rose-600 hover:text-rose-700 font-semibold flex items-center gap-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Xóa ảnh nền</span>
                </button>
              )}
            </div>

            <div className="p-4 rounded-xl border-2 border-dashed border-slate-300 bg-slate-50 hover:bg-slate-100/70 transition-colors text-center">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
                id="bg-upload-input"
              />
              <label
                htmlFor="bg-upload-input"
                className="cursor-pointer flex flex-col items-center justify-center gap-2"
              >
                <div className="w-10 h-10 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center">
                  <ImageIcon className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs sm:text-sm font-semibold text-indigo-600 hover:underline">
                    Nhấp để tải ảnh lên
                  </span>{' '}
                  <span className="text-xs text-slate-500">từ máy tính hoặc điện thoại</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Hỗ trợ JPG, PNG, WEBP. Ảnh sẽ được tự động lưu vào bộ nhớ trình duyệt!
                </p>
              </label>
            </div>

            {/* Background preview and opacity control */}
            {decoration.backgroundImage && (
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-700">Độ mờ ảnh nền (Opacity):</span>
                  <span className="text-xs font-mono text-slate-600">
                    {Math.round(decoration.backgroundOpacity * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0.05"
                  max="0.8"
                  step="0.05"
                  value={decoration.backgroundOpacity}
                  onChange={(e) =>
                    onUpdateDecoration({
                      ...decoration,
                      backgroundOpacity: Number(e.target.value),
                    })
                  }
                  className="w-full accent-indigo-600 cursor-pointer"
                />
                <p className="text-[11px] text-slate-500 italic">
                  💡 Nên để độ mờ từ 15% - 30% để chữ và các ô môn học nhìn rõ ràng nhất!
                </p>
              </div>
            )}
          </div>

          {/* Stickers */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <Smile className="w-3.5 h-3.5 text-indigo-500" />
                <span>Dán Sticker Trang Trí (Nhấp để thêm)</span>
              </label>
              {(decoration.stickers || []).length > 0 && (
                <button
                  onClick={handleClearStickers}
                  className="text-xs text-slate-500 hover:text-rose-600 transition-colors"
                >
                  Xóa hết ({decoration.stickers.length}) sticker
                </button>
              )}
            </div>

            <div className="flex flex-wrap gap-2 p-3 bg-slate-50 rounded-xl border border-slate-200">
              {STICKER_LIBRARY.map((stk, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => handleAddSticker(stk)}
                  className="w-9 h-9 text-xl flex items-center justify-center bg-white rounded-lg border border-slate-200 hover:scale-125 hover:shadow-sm transition-transform cursor-pointer"
                  title="Nhấp để dán sticker lên thời khóa biểu"
                >
                  {stk}
                </button>
              ))}
            </div>
            <p className="text-[11px] text-slate-500">
              * Khi dán lên thời khóa biểu, bạn có thể nhấn giữ và kéo sticker đến bất kỳ vị trí nào bạn thích!
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end px-6 py-3.5 border-t border-slate-200 bg-slate-50">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs sm:text-sm font-semibold bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-xs transition-colors"
          >
            Hoàn Tất
          </button>
        </div>
      </div>
    </div>
  );
};
