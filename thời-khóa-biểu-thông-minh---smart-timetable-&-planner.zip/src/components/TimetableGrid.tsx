import React from 'react';
import { Plus, MapPin, User, BookOpen, Clock, Calendar, Sparkles, Bell, Coffee, Sun, Moon } from 'lucide-react';
import { TimetableData, SubjectItem, DayOfWeek } from '../types/timetable';
import { DAYS_OF_WEEK, DEFAULT_PERIODS, THEMES } from '../constants/initialData';
import { getTodayKey, isPeriodActive } from '../utils/dateHelper';
import { StickerOverlay } from './StickerOverlay';

interface TimetableGridProps {
  data: TimetableData;
  onSelectSubject: (subject: SubjectItem) => void;
  onAddSubject: (day: DayOfWeek, period: number) => void;
  onUpdateStickers: (stickers: any[]) => void;
  timetableRef: React.RefObject<HTMLDivElement | null>;
  onOpenWelcomeModal?: () => void;
}

export const TimetableGrid: React.FC<TimetableGridProps> = ({
  data,
  onSelectSubject,
  onAddSubject,
  onUpdateStickers,
  timetableRef,
  onOpenWelcomeModal,
}) => {
  const todayKey = getTodayKey();

  // Days visible in the grid (e.g. Mon-Sat or Mon-Sun)
  const days = DAYS_OF_WEEK.filter((d) => data.daysVisible.includes(d.key));

  // Morning periods (1 to 4)
  const morningP1 = DEFAULT_PERIODS.find((p) => p.number === 1)!;
  const morningP2 = DEFAULT_PERIODS.find((p) => p.number === 2)!;
  const morningP3 = DEFAULT_PERIODS.find((p) => p.number === 3)!;
  const morningP4 = DEFAULT_PERIODS.find((p) => p.number === 4)!;

  // Afternoon periods (5 to 7: Tiết 1, 2, 3 chiều)
  const afternoonP1 = DEFAULT_PERIODS.find((p) => p.number === 5)!;
  const afternoonP2 = DEFAULT_PERIODS.find((p) => p.number === 6)!;
  const afternoonP3 = DEFAULT_PERIODS.find((p) => p.number === 7)!;

  // Map subjects for easy lookup: day_period -> SubjectItem
  const subjectMap = new Map<string, SubjectItem>();
  const coveredCells = new Set<string>();

  data.subjects.forEach((sub) => {
    const key = `${sub.day}_${sub.periodStart}`;
    subjectMap.set(key, sub);
    for (let p = sub.periodStart + 1; p < sub.periodStart + sub.periodSpan; p++) {
      coveredCells.add(`${sub.day}_${p}`);
    }
  });

  const renderSubjectCell = (day: DayOfWeek, periodNumber: number) => {
    const cellKey = `${day}_${periodNumber}`;

    // If this cell is part of an ongoing multi-period subject that started earlier, return null
    if (coveredCells.has(cellKey)) {
      return null;
    }

    const subject = subjectMap.get(cellKey);

    if (subject) {
      const isFree = Boolean(subject.isFreePeriod || subject.name.toLowerCase().includes('trống'));

      return (
        <td
          key={cellKey}
          rowSpan={subject.periodSpan}
          onClick={() => onSelectSubject(subject)}
          className="p-1 sm:p-1.5 align-top transition-transform hover:scale-[1.01] cursor-pointer"
        >
          <div
            className={`w-full h-full min-h-[76px] rounded-xl p-2.5 flex flex-col justify-between shadow-xs border transition-all hover:shadow-md relative overflow-hidden group ${
              isFree ? 'bg-slate-100/90 border-dashed border-slate-300' : ''
            }`}
            style={{
              backgroundColor: isFree ? '#f1f5f9' : `${subject.color}18`,
              borderColor: isFree ? '#cbd5e1' : `${subject.color}50`,
            }}
          >
            {/* Left accent stripe */}
            <div
              className="absolute left-0 top-0 bottom-0 w-1.5"
              style={{ backgroundColor: isFree ? '#94a3b8' : subject.color }}
            />

            <div>
              <div className="flex items-start justify-between gap-1">
                <h4
                  className="font-extrabold text-xs sm:text-sm line-clamp-2 flex items-center gap-1"
                  style={{ color: isFree ? '#475569' : subject.color }}
                >
                  {isFree && <span>☕</span>}
                  <span>{subject.name}</span>
                </h4>
                {subject.periodSpan > 1 && (
                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-white/80 text-slate-700 shadow-2xs shrink-0">
                    {subject.periodSpan} tiết
                  </span>
                )}
              </div>

              {/* Room & Teacher */}
              <div className="mt-1 space-y-0.5 text-[11px] text-slate-600">
                {isFree ? (
                  <div className="text-[10px] text-slate-500 font-medium italic">
                    🛋️ Không có ai dạy • Tự học / Nghỉ
                  </div>
                ) : (
                  <>
                    {subject.room && (
                      <div className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                        <span className="truncate">{subject.room}</span>
                      </div>
                    )}
                    {subject.teacher && (
                      <div className="flex items-center gap-1">
                        <User className="w-3 h-3 text-slate-400 shrink-0" />
                        <span className="truncate">{subject.teacher}</span>
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>

            {/* Bottom tags: Materials & notes preview */}
            <div className="mt-1.5 pt-1 border-t border-slate-200/50 flex items-center justify-between gap-1 text-[10px]">
              {isFree ? (
                <span className="text-slate-400 font-medium">Tiết tự do</span>
              ) : subject.requiredMaterials && subject.requiredMaterials.length > 0 ? (
                <span className="text-amber-800 font-medium truncate flex items-center gap-1" title={subject.requiredMaterials.join(', ')}>
                  <span>🎒</span>
                  <span className="truncate">{subject.requiredMaterials.length} dụng cụ</span>
                </span>
              ) : (
                <span className="text-slate-400">Không có ghi chú</span>
              )}

              {subject.homework && (
                <span className="text-rose-600 font-bold shrink-0" title="Có bài tập về nhà">
                  BTVN 📝
                </span>
              )}
            </div>
          </div>
        </td>
      );
    }

    // Empty slot
    return (
      <td
        key={cellKey}
        onClick={() => onAddSubject(day, periodNumber)}
        className="p-1 sm:p-1.5 align-middle text-center cursor-pointer group"
      >
        <div className="w-full h-full min-h-[64px] rounded-xl border border-dashed border-slate-200 hover:border-indigo-400 hover:bg-indigo-50/40 transition-all flex flex-col items-center justify-center text-slate-300 group-hover:text-indigo-600">
          <Plus className="w-4 h-4 opacity-0 group-hover:opacity-100 group-hover:scale-110 transition-all" />
          <span className="text-[10px] font-medium opacity-0 group-hover:opacity-100 transition-opacity hidden sm:inline">
            + Thêm môn
          </span>
        </div>
      </td>
    );
  };

  const renderPeriodRow = (period: typeof DEFAULT_PERIODS[0]) => {
    const isActive = isPeriodActive(period);
    return (
      <tr
        key={period.number}
        className={`border-b border-slate-100 hover:bg-slate-50/30 transition-colors ${
          isActive ? 'bg-amber-50/40' : ''
        }`}
      >
        {/* Period info cell */}
        <td className="p-2 sm:p-2.5 text-xs text-slate-500 font-medium bg-slate-50/40 border-r border-slate-100 whitespace-nowrap">
          <div className="flex items-center gap-1.5">
            <span className="w-5 h-5 rounded-md bg-slate-200/80 text-slate-700 font-bold flex items-center justify-center text-[11px]">
              {period.displayOrder}
            </span>
            <div>
              <span className="font-bold text-slate-700 block text-xs">
                {period.label}
              </span>
              <span className="text-[10px] text-slate-400 block">
                {period.startTime} - {period.endTime}
              </span>
            </div>
          </div>
        </td>

        {/* Day cells */}
        {days.map((day) => renderSubjectCell(day.key, period.number))}
      </tr>
    );
  };

  return (
    <div className="relative rounded-3xl overflow-hidden border border-slate-200/80 shadow-sm bg-white">
      {/* Target export container */}
      <div
        ref={timetableRef}
        className={`relative w-full overflow-hidden p-4 sm:p-6 transition-all ${
          data.decoration.theme === 'chalkboard'
            ? 'bg-slate-900 text-slate-100'
            : 'bg-white text-slate-800'
        }`}
      >
        {/* Custom Uploaded Background Image (Layer 0) */}
        {data.decoration.backgroundImage && (
          <div
            className="absolute inset-0 bg-cover bg-center pointer-events-none z-0 transition-opacity"
            style={{
              backgroundImage: `url(${data.decoration.backgroundImage})`,
              opacity: data.decoration.backgroundOpacity || 0.2,
            }}
          />
        )}

        {/* In-app Drawing Canvas Overlay (Layer 15) */}
        {data.decoration.drawingDataUrl && (
          <img
            src={data.decoration.drawingDataUrl}
            alt="Hand-drawn overlay"
            className="absolute inset-0 w-full h-full object-fill pointer-events-none z-15 select-none"
          />
        )}

        {/* Interactive Sticker Overlay (Layer 20) */}
        <StickerOverlay
          stickers={data.decoration.stickers || []}
          onUpdateStickers={onUpdateStickers}
          isEditable={true}
        />

        {/* Content Wrapper (Layer 10) */}
        <div className="relative z-10 space-y-4">
          {/* Header Banner on Timetable */}
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 pb-4 border-b border-slate-200/80">
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <span className="text-2xl">📅</span>
                <h2 className="text-xl sm:text-2xl font-black tracking-tight text-slate-800">
                  {data.decoration.title || 'Thời Khóa Biểu Của Tôi'}
                </h2>
                {data.userProfile?.className && (
                  <button
                    onClick={onOpenWelcomeModal}
                    className="text-xs bg-indigo-100 hover:bg-indigo-200 text-indigo-800 font-bold px-3 py-1 rounded-full transition-colors flex items-center gap-1 shadow-2xs"
                    title="Nhấp để đổi thông tin lớp học"
                  >
                    <span>🏫 {data.userProfile.className}</span>
                    {data.userProfile.studentName && <span>• {data.userProfile.studentName}</span>}
                  </button>
                )}
              </div>
              <p className="text-xs sm:text-sm text-slate-500 font-medium mt-1">
                {data.decoration.subtitle || 'Chúc bạn mỗi ngày đến trường là một ngày vui!'}
              </p>
            </div>

            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 flex-wrap">
              <span className="flex items-center gap-1 bg-amber-50 text-amber-800 border border-amber-200 px-2.5 py-1 rounded-lg">
                <Sun className="w-3.5 h-3.5 text-amber-600" />
                <span>Sáng: 4 Tiết</span>
              </span>
              <span className="flex items-center gap-1 bg-sky-50 text-sky-800 border border-sky-200 px-2.5 py-1 rounded-lg">
                <Clock className="w-3.5 h-3.5 text-sky-600" />
                <span>Chiều: 3 Tiết</span>
              </span>
              <span className="flex items-center gap-1 bg-slate-100 px-2.5 py-1 rounded-lg">
                <Calendar className="w-3.5 h-3.5 text-rose-500" />
                <span>{days.length} Ngày/Tuần</span>
              </span>
            </div>
          </div>

          {/* Empty state encouragement if no subjects have been added yet */}
          {data.subjects.length === 0 && (
            <div className="p-4 rounded-2xl bg-indigo-50/80 border border-indigo-200/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-indigo-900">
              <div className="flex items-center gap-3 text-center sm:text-left">
                <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0">
                  <BookOpen className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold">Thời khóa biểu hiện đang để trống</h4>
                  <p className="text-xs text-indigo-700/80">
                    Hãy nhấp vào các ô tiết học bên dưới hoặc nút <strong>"+ Thêm Môn"</strong> để bắt đầu nhập lịch học của bạn nhé!
                  </p>
                </div>
              </div>
              <button
                onClick={() => onAddSubject('monday', 1)}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors shrink-0 flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>Thêm Môn Đầu Tiên</span>
              </button>
            </div>
          )}

          {/* Table Container with Smooth Horizontal Scroll on mobile */}
          <div className="overflow-x-auto rounded-2xl border border-slate-200/80 shadow-2xs">
            <table className="w-full border-collapse min-w-[760px]">
              {/* Day Header Row */}
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs">
                  <th className="py-3 px-3 w-32 text-left font-bold text-slate-500 uppercase tracking-wider">
                    Tiết / Giờ
                  </th>
                  {days.map((day) => {
                    const isToday = day.key === todayKey;
                    return (
                      <th
                        key={day.key}
                        className={`py-3 px-2 text-center font-bold transition-colors ${
                          isToday
                            ? 'bg-indigo-50/80 text-indigo-700 border-x-2 border-indigo-500'
                            : 'text-slate-700'
                        }`}
                      >
                        <div className="flex flex-col items-center justify-center">
                          <span className="text-xs sm:text-sm">{day.name}</span>
                          {isToday && (
                            <span className="text-[10px] bg-indigo-600 text-white font-semibold px-2 py-0.2 rounded-full mt-0.5">
                              Hôm nay
                            </span>
                          )}
                        </div>
                      </th>
                    );
                  })}
                </tr>
              </thead>

              <tbody>
                {/* === CA SÁNG: Header === */}
                <tr className="bg-amber-500/10 border-y border-amber-200">
                  <td
                    colSpan={days.length + 1}
                    className="py-1.5 px-3 text-xs font-bold text-amber-900 tracking-wider flex items-center gap-2"
                  >
                    <span>☀️ BUỔI SÁNG: Tiết 1, Tiết 2, RA CHƠI, Tiết 3, Tiết 4</span>
                  </td>
                </tr>

                {/* Sáng: Tiết 1 */}
                {renderPeriodRow(morningP1)}

                {/* Sáng: Tiết 2 */}
                {renderPeriodRow(morningP2)}

                {/* === SÁNG: GIỜ RA CHƠI === */}
                <tr className="bg-gradient-to-r from-amber-100/90 via-orange-100/70 to-amber-100/90 border-y border-amber-300/80 select-none">
                  <td className="p-2 text-center font-bold text-amber-900 text-xs border-r border-amber-200/60">
                    <div className="flex items-center justify-center gap-1">
                      <Bell className="w-3.5 h-3.5 text-amber-700" />
                      <span>RA CHƠI</span>
                    </div>
                    <span className="text-[10px] font-normal text-amber-700 block">
                      08:35 - 09:00 (25p)
                    </span>
                  </td>
                  <td
                    colSpan={days.length}
                    className="p-2 text-center text-xs font-bold text-amber-900/90 tracking-wide"
                  >
                    🔔 GIỜ RA CHƠI • Nghỉ giải lao, ăn sáng &amp; tập thể dục giữa giờ 🏃‍♀️🍎
                  </td>
                </tr>

                {/* Sáng: Tiết 3 */}
                {renderPeriodRow(morningP3)}

                {/* Sáng: Tiết 4 */}
                {renderPeriodRow(morningP4)}

                {/* === RA VỀ HOẶC NGHỈ TRƯA === */}
                <tr className="bg-gradient-to-r from-emerald-100/80 via-teal-100/60 to-emerald-100/80 border-y-2 border-emerald-300 select-none">
                  <td className="p-2.5 text-center font-bold text-emerald-950 text-xs border-r border-emerald-200">
                    <div className="flex items-center justify-center gap-1">
                      <Coffee className="w-3.5 h-3.5 text-emerald-700" />
                      <span>NGHỈ TRƯA</span>
                    </div>
                    <span className="text-[10px] font-normal text-emerald-800 block">
                      10:35 - 13:30
                    </span>
                  </td>
                  <td
                    colSpan={days.length}
                    className="p-2.5 text-center text-xs font-bold text-emerald-900 tracking-wide"
                  >
                    🍱 RA VỀ HOẶC NGHỈ TRƯA • Ăn cơm trưa &amp; chợp mắt nghỉ ngơi nạp lại năng lượng 💤
                  </td>
                </tr>

                {/* === CA CHIỀU: Header === */}
                <tr className="bg-sky-500/10 border-y border-sky-200">
                  <td
                    colSpan={days.length + 1}
                    className="py-1.5 px-3 text-xs font-bold text-sky-900 tracking-wider flex items-center gap-2"
                  >
                    <span>🌤️ BUỔI CHIỀU: Tiết 1, Tiết 2, RA CHƠI, Tiết 3, RA VỀ</span>
                  </td>
                </tr>

                {/* Chiều: Tiết 1 Chiều (Period 5) */}
                {renderPeriodRow(afternoonP1)}

                {/* Chiều: Tiết 2 Chiều (Period 6) */}
                {renderPeriodRow(afternoonP2)}

                {/* === CHIỀU: GIỜ RA CHƠI === */}
                <tr className="bg-gradient-to-r from-sky-100/90 via-indigo-100/70 to-sky-100/90 border-y border-sky-300/80 select-none">
                  <td className="p-2 text-center font-bold text-sky-900 text-xs border-r border-sky-200/60">
                    <div className="flex items-center justify-center gap-1">
                      <Bell className="w-3.5 h-3.5 text-sky-700" />
                      <span>RA CHƠI</span>
                    </div>
                    <span className="text-[10px] font-normal text-sky-700 block">
                      15:05 - 15:25 (20p)
                    </span>
                  </td>
                  <td
                    colSpan={days.length}
                    className="p-2 text-center text-xs font-bold text-sky-900/90 tracking-wide"
                  >
                    🔔 GIỜ RA CHƠI CHIỀU • Giải lao, vận động nhẹ, uống nước 🧃✨
                  </td>
                </tr>

                {/* Chiều: Tiết 3 Chiều (Period 7) */}
                {renderPeriodRow(afternoonP3)}

                {/* === CHIỀU: RA VỀ === */}
                <tr className="bg-gradient-to-r from-rose-100/80 via-pink-100/60 to-rose-100/80 border-t-2 border-rose-300 select-none">
                  <td className="p-2.5 text-center font-bold text-rose-950 text-xs border-r border-rose-200">
                    <div className="flex items-center justify-center gap-1">
                      <span>🎒</span>
                      <span>RA VỀ</span>
                    </div>
                    <span className="text-[10px] font-normal text-rose-800 block">
                      16:10
                    </span>
                  </td>
                  <td
                    colSpan={days.length}
                    className="p-2.5 text-center text-xs font-bold text-rose-900 tracking-wide"
                  >
                    🎒 KẾT THÚC BUỔI HỌC • Chúc bạn ra về an toàn và có buổi tối ấm áp bên gia đình! 🏡🌟
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
