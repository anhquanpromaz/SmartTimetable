import React, { useState, useEffect } from 'react';
import { X, Plus, Trash2, BookOpen, Clock, MapPin, User, FileText, Check, Coffee } from 'lucide-react';
import { SubjectItem, DayOfWeek, UserProfile } from '../types/timetable';
import { DAYS_OF_WEEK, DEFAULT_PERIODS, SUBJECT_PRESETS, PALETTE_COLORS } from '../constants/initialData';

interface SubjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (subject: SubjectItem) => void;
  onDelete?: (id: string) => void;
  initialSubject?: Partial<SubjectItem> | null;
  defaultDay?: DayOfWeek;
  defaultPeriod?: number;
  userProfile?: UserProfile;
}

export const SubjectModal: React.FC<SubjectModalProps> = ({
  isOpen,
  onClose,
  onSave,
  onDelete,
  initialSubject,
  defaultDay = 'monday',
  defaultPeriod = 1,
  userProfile,
}) => {
  const [name, setName] = useState('');
  const [day, setDay] = useState<DayOfWeek>(defaultDay);
  const [periodStart, setPeriodStart] = useState<number>(defaultPeriod);
  const [periodSpan, setPeriodSpan] = useState<number>(1);
  const [room, setRoom] = useState('');
  const [teacher, setTeacher] = useState('');
  const [color, setColor] = useState('#3b82f6');
  const [notes, setNotes] = useState('');
  const [homework, setHomework] = useState('');
  const [materials, setMaterials] = useState<string[]>([]);
  const [newMaterialInput, setNewMaterialInput] = useState('');

  useEffect(() => {
    if (isOpen) {
      if (initialSubject && initialSubject.id) {
        setName(initialSubject.name || '');
        setDay(initialSubject.day || defaultDay);
        setPeriodStart(initialSubject.periodStart || defaultPeriod);
        setPeriodSpan(initialSubject.periodSpan || 1);
        setRoom(initialSubject.room || '');
        setTeacher(initialSubject.teacher || '');
        setColor(initialSubject.color || '#3b82f6');
        setNotes(initialSubject.notes || '');
        setHomework(initialSubject.homework || '');
        setMaterials(initialSubject.requiredMaterials || []);
      } else {
        // New item
        setName('');
        setDay(initialSubject?.day || defaultDay);
        setPeriodStart(initialSubject?.periodStart || defaultPeriod);
        setPeriodSpan(1);
        setRoom('');
        setTeacher('');
        setColor(PALETTE_COLORS[Math.floor(Math.random() * PALETTE_COLORS.length)]);
        setNotes('');
        setHomework('');
        setMaterials([]);
      }
    }
  }, [isOpen, initialSubject, defaultDay, defaultPeriod]);

  if (!isOpen) return null;

  const handleApplyPreset = (preset: typeof SUBJECT_PRESETS[0]) => {
    setName(preset.name);
    setColor(preset.defaultColor);
    setMaterials([...preset.defaultMaterials]);

    // Check if this is a free period (Tiết trống)
    if (preset.name.includes('Trống')) {
      setTeacher('Không có GV (Tự học)');
      setRoom('Tại lớp');
      setNotes('Tiết trống không có ai dạy, tranh thủ tự học hoặc nghỉ ngơi');
      return;
    }

    // Auto-fill teacher from userProfile if available
    if (preset.name.includes('Chào Cờ') || preset.name.includes('Sinh Hoạt')) {
      if (userProfile?.homeroomTeacher) {
        setTeacher(userProfile.homeroomTeacher);
      }
    } else if (userProfile?.subjectTeachers?.[preset.name]) {
      setTeacher(userProfile.subjectTeachers[preset.name]);
    }
  };

  const handleSetFreePeriodQuick = () => {
    setName('Tiết Trống');
    setColor('#94a3b8');
    setTeacher('Không có ai dạy');
    setRoom('Tại Lớp');
    setNotes('Tiết trống, tự học hoặc nghỉ ngơi');
    setMaterials([]);
  };

  const handleAddMaterial = () => {
    const trimmed = newMaterialInput.trim();
    if (trimmed && !materials.includes(trimmed)) {
      setMaterials([...materials, trimmed]);
      setNewMaterialInput('');
    }
  };

  const handleRemoveMaterial = (index: number) => {
    setMaterials(materials.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      alert('Vui lòng nhập tên môn học!');
      return;
    }

    const selectedPeriodInfo = DEFAULT_PERIODS.find((p) => p.number === Number(periodStart));
    const session = selectedPeriodInfo ? selectedPeriodInfo.session : (Number(periodStart) <= 4 ? 'morning' : 'afternoon');
    const isFree = name.toLowerCase().includes('trống');

    const subjectData: SubjectItem = {
      id: initialSubject?.id || `sub_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      name: name.trim(),
      day,
      periodStart: Number(periodStart),
      periodSpan: Number(periodSpan),
      session,
      room: room.trim() || undefined,
      teacher: teacher.trim() || undefined,
      color: isFree && color === '#3b82f6' ? '#94a3b8' : color,
      notes: notes.trim() || undefined,
      homework: homework.trim() || undefined,
      requiredMaterials: materials,
      isFreePeriod: isFree,
    };

    onSave(subjectData);
    onClose();
  };

  const isEditing = Boolean(initialSubject && initialSubject.id);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-xl bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-200 my-8">
        {/* Header */}
        <div 
          className="flex items-center justify-between px-6 py-4 text-white"
          style={{ backgroundColor: color }}
        >
          <div>
            <h2 className="text-lg font-bold flex items-center gap-2">
              <BookOpen className="w-5 h-5" />
              <span>{isEditing ? 'Chỉnh Sửa Môn Học' : 'Thêm Môn Học Mới'}</span>
            </h2>
            <p className="text-xs opacity-90">
              Nhập chi tiết môn học, phòng học, giáo viên và sách vở cần mang
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-white/80 hover:text-white rounded-lg hover:bg-black/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {/* Quick preset chips */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Gợi ý môn học nhanh (Click để chọn nhanh)
              </label>
              <button
                type="button"
                onClick={handleSetFreePeriodQuick}
                className="text-xs px-2.5 py-1 rounded-lg font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 transition-all flex items-center gap-1.5 shadow-2xs"
                title="Chọn tiết trống, không có giáo viên dạy"
              >
                <span>☕</span>
                <span>Đặt làm Tiết Trống</span>
              </button>
            </div>
            <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto p-1 bg-slate-50 rounded-xl border border-slate-100">
              {SUBJECT_PRESETS.map((preset) => (
                <button
                  key={preset.name}
                  type="button"
                  onClick={() => handleApplyPreset(preset)}
                  className={`text-xs px-2.5 py-1 rounded-lg font-medium transition-all flex items-center gap-1.5 border ${
                    name === preset.name
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                      : 'bg-white text-slate-700 hover:bg-slate-100 border-slate-200'
                  }`}
                >
                  <span>{preset.icon}</span>
                  <span>{preset.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Subject Name & Color */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Tên Môn Học <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="VD: Toán Học, Ngữ Văn..."
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Màu sắc thẻ môn
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={color}
                  onChange={(e) => setColor(e.target.value)}
                  className="w-10 h-10 rounded-xl cursor-pointer border border-slate-200 p-0.5"
                />
                <span className="text-xs font-mono text-slate-500">{color}</span>
              </div>
            </div>
          </div>

          {/* Day & Period Selection */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-slate-400" /> Thứ trong tuần
              </label>
              <select
                value={day}
                onChange={(e) => setDay(e.target.value as DayOfWeek)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium bg-white"
              >
                {DAYS_OF_WEEK.map((d) => (
                  <option key={d.key} value={d.key}>
                    {d.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Bắt đầu từ tiết
              </label>
              <select
                value={periodStart}
                onChange={(e) => setPeriodStart(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium bg-white"
              >
                <optgroup label="☀️ Buổi Sáng">
                  {DEFAULT_PERIODS.filter(p => p.session === 'morning').map((p) => (
                    <option key={p.number} value={p.number}>
                      {p.label} ({p.startTime} - {p.endTime})
                    </option>
                  ))}
                </optgroup>
                <optgroup label="🌤️ Buổi Chiều">
                  {DEFAULT_PERIODS.filter(p => p.session === 'afternoon').map((p) => (
                    <option key={p.number} value={p.number}>
                      {p.label} ({p.startTime} - {p.endTime})
                    </option>
                  ))}
                </optgroup>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Số tiết học
              </label>
              <select
                value={periodSpan}
                onChange={(e) => setPeriodSpan(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium bg-white"
              >
                <option value={1}>1 Tiết (45 phút)</option>
                <option value={2}>2 Tiết liền</option>
                <option value={3}>3 Tiết</option>
                <option value={4}>4 Tiết</option>
              </select>
            </div>
          </div>

          {/* Room & Teacher */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-slate-400" /> Phòng học
              </label>
              <input
                type="text"
                placeholder="VD: Phòng 204, Lab Tin..."
                value={room}
                onChange={(e) => setRoom(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
                <User className="w-3.5 h-3.5 text-slate-400" /> Giáo viên phụ trách
              </label>
              <input
                type="text"
                placeholder="VD: Thầy Nam, Cô Hằng..."
                value={teacher}
                onChange={(e) => setTeacher(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Sách vở & Đồ dùng cần mang (Smart reminder core feature) */}
          <div className="bg-amber-50/60 p-3.5 rounded-xl border border-amber-200">
            <label className="block text-xs font-bold text-amber-900 mb-1 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                🎒 Sách vở &amp; Dụng cụ cần mang
              </span>
              <span className="text-[11px] font-normal text-amber-700">
                (Tự động nhắc nhở khi soạn balo)
              </span>
            </label>

            {/* Existing material tags */}
            <div className="flex flex-wrap gap-1.5 mb-2.5">
              {materials.length === 0 ? (
                <span className="text-xs text-amber-800/70 italic">
                  Chưa có sách vở nào. Hãy thêm để được nhắc nhở soạn bài!
                </span>
              ) : (
                materials.map((m, idx) => (
                  <span
                    key={idx}
                    className="inline-flex items-center gap-1 text-xs bg-amber-100/90 text-amber-900 font-medium px-2.5 py-1 rounded-lg border border-amber-200"
                  >
                    <span>{m}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveMaterial(idx)}
                      className="text-amber-700 hover:text-rose-600 transition-colors"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))
              )}
            </div>

            {/* Input to add material */}
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="VD: SGK Toán 11, Máy tính Casio, Thước kẻ..."
                value={newMaterialInput}
                onChange={(e) => setNewMaterialInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddMaterial();
                  }
                }}
                className="flex-1 px-3 py-1.5 rounded-lg border border-amber-300 bg-white text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
              <button
                type="button"
                onClick={handleAddMaterial}
                className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-medium flex items-center gap-1 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Thêm</span>
              </button>
            </div>
          </div>

          {/* Notes & Homework */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
                <FileText className="w-3.5 h-3.5 text-slate-400" /> Ghi chú môn học
              </label>
              <textarea
                rows={2}
                placeholder="VD: Kiểm tra miệng, mặc đồng phục thể dục..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full px-3 py-1.5 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
                📝 Bài tập về nhà cần nộp
              </label>
              <textarea
                rows={2}
                placeholder="VD: Làm bài tập 1, 2, 3 trang 45..."
                value={homework}
                onChange={(e) => setHomework(e.target.value)}
                className="w-full px-3 py-1.5 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Modal Buttons */}
          <div className="flex items-center justify-between pt-3 border-t border-slate-100">
            {isEditing && onDelete && initialSubject?.id ? (
              <button
                type="button"
                onClick={() => {
                  if (confirm(`Bạn có chắc muốn xóa môn "${name}" khỏi thời khóa biểu?`)) {
                    onDelete(initialSubject.id!);
                    onClose();
                  }
                }}
                className="text-xs text-rose-600 hover:text-rose-700 font-semibold flex items-center gap-1 px-3 py-2 rounded-xl hover:bg-rose-50 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
                <span>Xóa Môn Này</span>
              </button>
            ) : (
              <div />
            )}

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
              >
                Hủy bỏ
              </button>
              <button
                type="submit"
                className="px-5 py-2 text-xs sm:text-sm font-semibold bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-md shadow-indigo-200 transition-colors flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>{isEditing ? 'Lưu Thay Đổi' : 'Thêm Vào TKB'}</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
