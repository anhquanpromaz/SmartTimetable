import React, { useState } from 'react';
import { X } from 'lucide-react';
import { TimetableSticker } from '../types/timetable';

interface StickerOverlayProps {
  stickers: TimetableSticker[];
  onUpdateStickers: (stickers: TimetableSticker[]) => void;
  isEditable?: boolean;
}

export const StickerOverlay: React.FC<StickerOverlayProps> = ({
  stickers,
  onUpdateStickers,
  isEditable = true,
}) => {
  const [activeStickerId, setActiveStickerId] = useState<string | null>(null);

  const handlePointerDown = (id: string, e: React.PointerEvent) => {
    if (!isEditable) return;
    setActiveStickerId(id);
    const target = e.currentTarget as HTMLElement;
    target.setPointerCapture(e.pointerId);

    const startX = e.clientX;
    const startY = e.clientY;
    const parent = target.offsetParent as HTMLElement;
    if (!parent) return;

    const parentRect = parent.getBoundingClientRect();
    const sticker = stickers.find((s) => s.id === id);
    if (!sticker) return;

    const initialX = (sticker.x / 100) * parentRect.width;
    const initialY = (sticker.y / 100) * parentRect.height;

    const handlePointerMove = (moveEvent: PointerEvent) => {
      const dx = moveEvent.clientX - startX;
      const dy = moveEvent.clientY - startY;

      const newPxX = Math.max(0, Math.min(parentRect.width - 40, initialX + dx));
      const newPxY = Math.max(0, Math.min(parentRect.height - 40, initialY + dy));

      const newPercentX = (newPxX / parentRect.width) * 100;
      const newPercentY = (newPxY / parentRect.height) * 100;

      onUpdateStickers(
        stickers.map((s) =>
          s.id === id ? { ...s, x: newPercentX, y: newPercentY } : s
        )
      );
    };

    const handlePointerUp = (upEvent: PointerEvent) => {
      target.releasePointerCapture(upEvent.pointerId);
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
      setActiveStickerId(null);
    };

    window.addEventListener('pointermove', handlePointerMove);
    window.addEventListener('pointerup', handlePointerUp);
  };

  const handleRemove = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    onUpdateStickers(stickers.filter((s) => s.id !== id));
  };

  return (
    <div className="absolute inset-0 pointer-events-none z-20 overflow-hidden">
      {stickers.map((sticker) => (
        <div
          key={sticker.id}
          onPointerDown={(e) => handlePointerDown(sticker.id, e)}
          style={{
            position: 'absolute',
            left: `${sticker.x}%`,
            top: `${sticker.y}%`,
            transform: `rotate(${sticker.rotation}deg)`,
            fontSize: `${sticker.size}px`,
            cursor: isEditable ? 'grab' : 'default',
          }}
          className={`pointer-events-auto group select-none transition-shadow ${
            activeStickerId === sticker.id ? 'scale-110 cursor-grabbing z-30' : ''
          }`}
          title={isEditable ? 'Kéo để di chuyển, nhấp dấu X để xóa' : undefined}
        >
          <div className="relative">
            {sticker.type === 'emoji' ? (
              <span className="drop-shadow-md inline-block hover:scale-110 transition-transform">
                {sticker.content}
              </span>
            ) : (
              <img
                src={sticker.content}
                alt="sticker"
                className="w-12 h-12 object-contain drop-shadow-md"
              />
            )}

            {isEditable && (
              <button
                type="button"
                onClick={(e) => handleRemove(sticker.id, e)}
                className="absolute -top-2 -right-2 bg-rose-500 text-white rounded-full p-0.5 opacity-0 group-hover:opacity-100 hover:scale-110 transition-all shadow-sm"
                title="Gỡ sticker"
              >
                <X className="w-2.5 h-2.5" />
              </button>
            )}
          </div>
        </div>
      ))}
    </div>
  );
};
