import React, { useState } from 'react';
import { 
  Sparkles, 
  GraduationCap, 
  User, 
  Calendar, 
  ArrowRight, 
  ArrowLeft,
  Check, 
  BookOpen, 
  Users, 
  Coffee,
  HelpCircle
} from 'lucide-react';
import { UserProfile, DayOfWeek } from '../types/timetable';
import { GRADE_PRESETS, COMMON_TEACHER_SUBJECTS } from '../constants/initialData';

interface WelcomeModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialProfile?: UserProfile;
  onSaveProfile: (profile: UserProfile, daysVisible: DayOfWeek[], title: string) => void;
  isFirstTime?: boolean;
}

export const WelcomeModal: React.FC<WelcomeModalProps> = ({
  isOpen,
  onClose,
  initialProfile,
  onSaveProfile,
  isFirstTime = true,
}) => {
  // Step state: 1: Class & Name, 2: Homeroom Teacher & Subject Teachers, 3: Schedule
  const [step, setStep] = useState<number>(1);

  const [selectedGrade, setSelectedGrade] = useState<string>(
    initialProfile?.className?.split(' ')[0] || 'Lớp 10'
  );
  const [classNameInput, setClassNameInput] = useState<string>(
    initialProfile?.className || 'Lớp 10A1'
  );
  const [studentName, setStudentName] = useState<string>(
    initialProfile?.studentName || ''
  );
  const [homeroomTeacher, setHomeroomTeacher] = useState<string>(
    initialProfile?.homeroomTeacher || ''
  );
  const [subjectTeachers, setSubjectTeachers] = useState<Record<string, string>>(
    initialProfile?.subjectTeachers || {}
  );
  const [scheduleOption, setScheduleOption] = useState<'5_days' | '6_days' | '7_days'>('6_days');

  if (!isOpen) return null;

  const handleGradeChipClick = (grade: string) => {
    setSelectedGrade(grade);
    if (!classNameInput || classNameInput.startsWith('Lớp')) {
      setClassNameInput(`${grade}A1`);
    }
  };

  const handleTeacherChange = (subjectName: string, teacherName: string) => {
    setSubjectTeachers((prev) => ({
      ...prev,
      [subjectName]: teacherName,
    }));
  };

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const finalClassName = classNameInput.trim() || selectedGrade || 'Lớp của tôi';
    const profile: UserProfile = {
      className: finalClassName,
      studentName: studentName.trim(),
      homeroomTeacher: homeroomTeacher.trim(),
      subjectTeachers,
      hasCompletedWelcome: true,
    };

    let days: DayOfWeek[] = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    if (scheduleOption === '5_days') {
      days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'];
    } else if (scheduleOption === '7_days') {
      days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
    }

    const title = studentName.trim()
      ? `Thời Khóa Biểu Của ${studentName.trim()}`
      : `Thời Khóa Biểu ${finalClassName}`;

    onSaveProfile(profile, days, title);
    onClose();
  };

  // Dynamic question formulation for Homeroom teacher as requested by user:
  // "Giáo Viên Chủ Nhiệm của [tên] là ai?"
  const displayName = studentName.trim() || 'bạn';
  const homeroomQuestion = `Giáo Viên Chủ Nhiệm của ${displayName} là ai?`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-3 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-200 my-6 animate-in fade-in zoom-in-95 duration-200 flex flex-col max-h-[92vh]">
        {/* Banner with Greeting */}
        <div className="relative overflow-hidden bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500 p-5 sm:p-6 text-white shrink-0">
          <div className="absolute -right-6 -bottom-6 w-32 h-32 bg-white/10 rounded-full blur-xl pointer-events-none" />
          
          <div className="relative z-10 space-y-1.5">
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-md px-3 py-0.5 rounded-full text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
              <span>Chào mừng bạn!</span>
            </div>
            <h1 className="text-lg sm:text-xl font-black tracking-tight leading-snug">
              Chào mừng bạn đến với công cụ Thời Khóa Biểu! ✨
            </h1>
            <p className="text-xs sm:text-sm text-white/90 leading-relaxed">
              Thiết lập thông tin lớp học và thầy cô để tự động điền khi lập lịch học nhé!
            </p>
          </div>

          {/* Stepper Dots */}
          <div className="flex items-center gap-2 mt-4 pt-2 border-t border-white/20">
            <button
              type="button"
              onClick={() => setStep(1)}
              className={`flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-lg transition-all ${
                step === 1 ? 'bg-white text-indigo-900 font-bold shadow-xs' : 'text-white/80 hover:bg-white/10'
              }`}
            >
              <span>1. Lớp &amp; Tên</span>
            </button>
            <span className="text-white/40">→</span>
            <button
              type="button"
              onClick={() => setStep(2)}
              className={`flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-lg transition-all ${
                step === 2 ? 'bg-white text-indigo-900 font-bold shadow-xs' : 'text-white/80 hover:bg-white/10'
              }`}
            >
              <span>2. Thầy Cô Giáo</span>
            </button>
            <span className="text-white/40">→</span>
            <button
              type="button"
              onClick={() => setStep(3)}
              className={`flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-lg transition-all ${
                step === 3 ? 'bg-white text-indigo-900 font-bold shadow-xs' : 'text-white/80 hover:bg-white/10'
              }`}
            >
              <span>3. Lịch Tuần</span>
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 overflow-y-auto flex-1 space-y-5">
          {/* STEP 1: CLASS & STUDENT NAME */}
          {step === 1 && (
            <div className="space-y-4 animate-in fade-in duration-200">
              {/* Chọn Khối Lớp */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                  <GraduationCap className="w-4 h-4 text-indigo-600" />
                  <span>Chọn khối lớp của bạn</span>
                </label>
                <div className="space-y-2 max-h-36 overflow-y-auto p-2 bg-slate-50 rounded-2xl border border-slate-100">
                  {GRADE_PRESETS.map((group) => (
                    <div key={group.level} className="space-y-1">
                      <span className="text-[10px] font-bold text-slate-400 block px-1">
                        {group.level}
                      </span>
                      <div className="flex flex-wrap gap-1.5 px-1">
                        {group.grades.map((grade) => (
                          <button
                            key={grade}
                            type="button"
                            onClick={() => handleGradeChipClick(grade)}
                            className={`text-xs px-2.5 py-1 rounded-xl font-medium transition-all ${
                              selectedGrade === grade
                                ? 'bg-indigo-600 text-white shadow-xs font-bold'
                                : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-200'
                            }`}
                          >
                            {grade}
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Tên Lớp Cụ Thể */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                  <BookOpen className="w-4 h-4 text-indigo-600" />
                  <span>Tên lớp học cụ thể</span>
                  <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={classNameInput}
                  onChange={(e) => setClassNameInput(e.target.value)}
                  placeholder="VD: Lớp 10A1, 12 Chuyên Toán, 7/3..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Tên Học Sinh */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                  <User className="w-4 h-4 text-indigo-600" />
                  <span>Tên của bạn</span>
                  <span className="text-[10px] text-slate-400 font-normal lowercase">(để gọi tên thân mật)</span>
                </label>
                <input
                  type="text"
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                  placeholder="VD: Minh Anh, Hoàng Nam, Linh..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs transition-all flex items-center justify-center gap-2"
                >
                  <span>Tiếp tục: Điền thông tin Thầy Cô</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: TEACHERS QUESTION & SUBJECT TEACHERS */}
          {step === 2 && (
            <div className="space-y-5 animate-in fade-in duration-200">
              {/* Question 1: Giáo viên chủ nhiệm của [tên] là ai? */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-indigo-50 via-purple-50 to-pink-50 border border-indigo-100 shadow-2xs space-y-2">
                <label className="block text-sm font-extrabold text-indigo-950 flex items-center gap-2">
                  <span className="text-xl">👩‍🏫</span>
                  <span>{homeroomQuestion}</span>
                </label>
                <p className="text-xs text-slate-600">
                  Thầy/Cô chủ nhiệm sẽ được tự động nhắc trong các tiết Sinh Hoạt, Chào Cờ hoặc tổng kết tuần.
                </p>
                <input
                  type="text"
                  value={homeroomTeacher}
                  onChange={(e) => setHomeroomTeacher(e.target.value)}
                  placeholder="VD: Cô Mai, Thầy Hưng, Cô Nguyễn Thị Lan..."
                  className="w-full px-3.5 py-2.5 bg-white rounded-xl border border-indigo-200 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Question 2: Giáo viên của từng môn học */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                    <Users className="w-4 h-4 text-indigo-600" />
                    <span>Giáo viên của từng môn học</span>
                  </label>
                  <span className="text-[11px] text-slate-400">
                    (Có thể điền những môn bạn biết)
                  </span>
                </div>
                <p className="text-xs text-slate-500">
                  Khi bạn thêm môn vào thời khóa biểu, tên thầy/cô sẽ được tự động điền sẵn để tiết kiệm thời gian!
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-56 overflow-y-auto p-2 bg-slate-50 rounded-2xl border border-slate-100">
                  {COMMON_TEACHER_SUBJECTS.map((subject) => (
                    <div key={subject} className="bg-white p-2 rounded-xl border border-slate-200 shadow-2xs flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-700 min-w-[70px] truncate" title={subject}>
                        {subject}:
                      </span>
                      <input
                        type="text"
                        placeholder="Tên thầy/cô..."
                        value={subjectTeachers[subject] || ''}
                        onChange={(e) => handleTeacherChange(subject, e.target.value)}
                        className="flex-1 px-2.5 py-1 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                      />
                    </div>
                  ))}
                </div>
              </div>

              {/* Navigation */}
              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors flex items-center gap-1"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Quay lại</span>
                </button>

                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs transition-all flex items-center gap-1.5"
                >
                  <span>Tiếp tục: Lịch học</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: SCHEDULE DAYS & FINAL CONFIRMATION */}
          {step === 3 && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                  <Calendar className="w-4 h-4 text-indigo-600" />
                  <span>Lịch học các ngày trong tuần của bạn</span>
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setScheduleOption('5_days')}
                    className={`p-3 rounded-2xl border text-center transition-all ${
                      scheduleOption === '5_days'
                        ? 'border-indigo-600 bg-indigo-50/80 text-indigo-900 font-bold ring-2 ring-indigo-500/20'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                    }`}
                  >
                    <span className="block text-xs font-bold">Thứ 2 - Thứ 6</span>
                    <span className="text-[10px] text-slate-400">5 ngày/tuần</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setScheduleOption('6_days')}
                    className={`p-3 rounded-2xl border text-center transition-all ${
                      scheduleOption === '6_days'
                        ? 'border-indigo-600 bg-indigo-50/80 text-indigo-900 font-bold ring-2 ring-indigo-500/20'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                    }`}
                  >
                    <span className="block text-xs font-bold">Thứ 2 - Thứ 7</span>
                    <span className="text-[10px] text-slate-400">Phổ biến nhất</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setScheduleOption('7_days')}
                    className={`p-3 rounded-2xl border text-center transition-all ${
                      scheduleOption === '7_days'
                        ? 'border-indigo-600 bg-indigo-50/80 text-indigo-900 font-bold ring-2 ring-indigo-500/20'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                    }`}
                  >
                    <span className="block text-xs font-bold">Cả tuần</span>
                    <span className="text-[10px] text-slate-400">+ Chủ Nhật</span>
                  </button>
                </div>
              </div>

              {/* Free Period tip */}
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 flex items-start gap-2.5 text-xs text-slate-600">
                <Coffee className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <p className="leading-relaxed">
                  <strong>Mẹo:</strong> Nếu trong tuần có tiết không ai dạy, bạn có thể chọn môn <strong>"Tiết Trống (Nghỉ/Tự Học)"</strong> để đánh dấu giờ tự học hoặc nghỉ ngơi nhé!
                </p>
              </div>

              {/* Navigation */}
              <div className="flex items-center justify-between pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors flex items-center gap-1"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Quay lại</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSubmit()}
                  className="px-6 py-2.5 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-700 hover:to-pink-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md shadow-indigo-200 transition-all flex items-center gap-2"
                >
                  <Check className="w-4 h-4" />
                  <span>Hoàn Tất &amp; Vào Lập TKB</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
