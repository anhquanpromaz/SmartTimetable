import React, { useState } from 'react';
import { 
  Sparkles, 
  CheckCircle2, 
  Circle, 
  Calendar, 
  Clock, 
  Backpack, 
  ArrowRight, 
  Coffee, 
  Sun, 
  BookOpen, 
  Award,
  ChevronRight,
  Flame,
  Layers
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { SubjectItem, DayOfWeek, TimetableData } from '../types/timetable';
import { 
  getTodayKey, 
  getTomorrowKey, 
  getDayName, 
  getFormattedDate, 
  isWeekend, 
  getTimeGreeting, 
  getSubjectsForDay,
  getRandomWeekendWish,
  getTodayDateString
} from '../utils/dateHelper';
import { DAYS_OF_WEEK, DEFAULT_PERIODS } from '../constants/initialData';

interface DailyDashboardProps {
  data: TimetableData;
  onUpdateAttendance: (key: string) => void;
  onOpenBackpackModal: (targetDay: DayOfWeek, isNextWeek?: boolean) => void;
  onOpenSubjectModal: (day?: DayOfWeek, period?: number) => void;
  onOpenDecorateModal: () => void;
  onOpenDrawingModal: () => void;
}

export const DailyDashboard: React.FC<DailyDashboardProps> = ({
  data,
  onUpdateAttendance,
  onOpenBackpackModal,
  onOpenSubjectModal,
}) => {
  // Real today
  const realTodayKey = getTodayKey();
  
  // Active viewing day (allows simulating weekend / any day preview easily)
  const [currentDay, setCurrentDay] = useState<DayOfWeek>(realTodayKey);
  const [weekendWish] = useState<string>(() => getRandomWeekendWish());

  const isCurrentWeekend = isWeekend(currentDay);
  const todayDateStr = getTodayDateString();
  const timeGreeting = getTimeGreeting();

  // Subjects for the active viewing day
  const todaySubjects = getSubjectsForDay(data.subjects, currentDay);

  // Tomorrow or Next Monday subjects
  const tomorrowKey = getTomorrowKey(currentDay);
  const nextMondayKey: DayOfWeek = 'monday';
  const reminderDayKey = isCurrentWeekend ? nextMondayKey : tomorrowKey;
  const reminderSubjects = getSubjectsForDay(data.subjects, reminderDayKey);

  // Calculate attendance stats for the active day
  const attendedCount = todaySubjects.filter(
    (s) => data.attendance[`${todayDateStr}_${s.id}`]
  ).length;
  const totalTodaySubjects = todaySubjects.length;
  const attendancePercent = totalTodaySubjects > 0 
    ? Math.round((attendedCount / totalTodaySubjects) * 100) 
    : 0;

  // Weekly review metrics (for weekend recap)
  const weekdayList: DayOfWeek[] = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'];
  const weeklySubjects = data.subjects.filter((s) => weekdayList.includes(s.day));
  const uniqueSubjectsCount = new Set(weeklySubjects.map((s) => s.name)).size;
  const totalWeeklyPeriods = weeklySubjects.reduce((acc, curr) => acc + curr.periodSpan, 0);

  const handleToggleAttendance = (subjectId: string) => {
    const key = `${todayDateStr}_${subjectId}`;
    const nextState = !data.attendance[key];
    onUpdateAttendance(key);

    if (nextState && attendedCount + 1 === totalTodaySubjects && totalTodaySubjects > 0) {
      confetti({
        particleCount: 100,
        spread: 80,
        origin: { y: 0.5 },
      });
    }
  };

  return (
    <div className="space-y-4 mb-6">
      {/* Top Bar: Date, Day Switcher & Quick Demo Controls */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3 bg-white/90 backdrop-blur-md p-4 rounded-2xl border border-slate-200/80 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-500 to-rose-500 flex items-center justify-center text-white shadow-sm shrink-0">
            <Calendar className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-md">
                {getFormattedDate()}
              </span>
              {currentDay === realTodayKey ? (
                <span className="text-[11px] bg-emerald-100 text-emerald-800 font-semibold px-2 py-0.5 rounded-full flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  Hôm nay
                </span>
              ) : (
                <span className="text-[11px] bg-amber-100 text-amber-800 font-semibold px-2 py-0.5 rounded-full">
                  Đang xem thử: {getDayName(currentDay)}
                </span>
              )}
            </div>
            <h1 className="text-lg sm:text-xl font-extrabold text-slate-800 mt-0.5">
              Hôm Nay: {getDayName(currentDay)}
            </h1>
          </div>
        </div>

        {/* Day simulator switcher */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-1 md:pb-0">
          <span className="text-xs text-slate-400 font-medium whitespace-nowrap hidden lg:inline">
            Xem ngày:
          </span>
          {DAYS_OF_WEEK.map((d) => (
            <button
              key={d.key}
              onClick={() => setCurrentDay(d.key)}
              className={`px-2.5 py-1.5 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
                currentDay === d.key
                  ? 'bg-indigo-600 text-white shadow-xs scale-105'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {d.shortName}
            </button>
          ))}
          {currentDay !== realTodayKey && (
            <button
              onClick={() => setCurrentDay(realTodayKey)}
              className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold ml-1 whitespace-nowrap underline"
            >
              Về hôm nay
            </button>
          )}
        </div>
      </div>

      {/* Main Condition Banner: WEEKEND vs WEEKDAY */}
      {isCurrentWeekend ? (
        /* ==================== WEEKEND VIEW ==================== */
        <div className="space-y-4">
          {/* Weekend Celebration Card */}
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-amber-400 via-rose-400 to-indigo-500 p-6 sm:p-8 text-white shadow-lg">
            <div className="absolute -right-8 -top-8 w-48 h-48 bg-white/10 rounded-full blur-2xl pointer-events-none" />
            <div className="absolute right-12 bottom-0 opacity-15 pointer-events-none">
              <Sun className="w-56 h-56" />
            </div>

            <div className="relative z-10 max-w-2xl space-y-3">
              <div className="inline-flex items-center gap-1.5 bg-white/20 backdrop-blur-md px-3 py-1 rounded-full text-xs font-semibold">
                <Coffee className="w-3.5 h-3.5" />
                <span>Nghỉ Ngơi Cuối Tuần</span>
              </div>

              <h2 className="text-xl sm:text-3xl font-extrabold tracking-tight leading-tight">
                Chúc bạn một ngày nghỉ cuối tuần thật vui vẻ và hạnh phúc! 🌸✨
              </h2>

              <p className="text-sm sm:text-base text-white/90 leading-relaxed font-medium">
                {weekendWish}
              </p>

              <div className="pt-2 flex flex-wrap items-center gap-3">
                <button
                  onClick={() => onOpenBackpackModal('monday', true)}
                  className="px-5 py-2.5 bg-white text-slate-900 hover:bg-amber-50 font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center gap-2"
                >
                  <Backpack className="w-4 h-4 text-orange-500" />
                  <span>Chuẩn Bị Sách Vở Cho Thứ Hai</span>
                </button>
                <div className="text-xs text-white/80 flex items-center gap-1">
                  <span>🏖️ Thư giãn, nạp năng lượng sẵn sàng cho tuần mới</span>
                </div>
              </div>
            </div>
          </div>

          {/* Weekend Review & Monday Reminder Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* 1. Điểm lại những môn đã học trong tuần (Weekly Recap) */}
            <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
                    <Award className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800 text-sm sm:text-base">
                      Điểm Lại Tuần Học Vừa Qua
                    </h3>
                    <p className="text-xs text-slate-500">
                      Tổng hợp những môn và kiến thức bạn đã hoàn thành
                    </p>
                  </div>
                </div>
                <span className="text-xs bg-indigo-100 text-indigo-700 font-bold px-2.5 py-1 rounded-full">
                  {totalWeeklyPeriods} tiết học
                </span>
              </div>

              {/* Weekly Highlights Stats */}
              <div className="grid grid-cols-3 gap-2.5 pt-1">
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 text-center">
                  <span className="block text-xl font-extrabold text-indigo-600">
                    {uniqueSubjectsCount}
                  </span>
                  <span className="text-[11px] text-slate-500 font-medium">Môn học khác nhau</span>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 text-center">
                  <span className="block text-xl font-extrabold text-emerald-600">
                    {weeklySubjects.length}
                  </span>
                  <span className="text-[11px] text-slate-500 font-medium">Buổi học trong tuần</span>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 text-center">
                  <span className="block text-xl font-extrabold text-rose-500">
                    100%
                  </span>
                  <span className="text-[11px] text-slate-500 font-medium">Nỗ lực chăm chỉ</span>
                </div>
              </div>

              {/* Day-by-day subject pills */}
              <div className="space-y-2 pt-2 border-t border-slate-100">
                <span className="text-xs font-bold text-slate-600 block">
                  Các môn đã học từ Thứ 2 đến Thứ 6:
                </span>
                <div className="flex flex-wrap gap-1.5 max-h-36 overflow-y-auto">
                  {weeklySubjects.map((sub, idx) => (
                    <span
                      key={idx}
                      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold border"
                      style={{
                        backgroundColor: `${sub.color}15`,
                        borderColor: `${sub.color}40`,
                        color: sub.color,
                      }}
                    >
                      <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: sub.color }} />
                      <span>{sub.name}</span>
                      <span className="text-[10px] opacity-75">({getDayName(sub.day).replace('Thứ ', 'T')})</span>
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* 2. Nhắc nhở Thứ Hai tuần tới học những môn gì */}
            <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-orange-50 text-orange-600 flex items-center justify-center font-bold">
                    <Backpack className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800 text-sm sm:text-base">
                      Nhắc Nhở: Thứ Hai Tuần Tới Học Gì?
                    </h3>
                    <p className="text-xs text-slate-500">
                      Chủ động chuẩn bị sách vở từ tối Chủ Nhật
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => onOpenBackpackModal('monday', true)}
                  className="text-xs font-bold text-orange-600 hover:text-orange-700 bg-orange-50 px-2.5 py-1 rounded-lg transition-colors flex items-center gap-1"
                >
                  <span>Soạn Balo</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>

              {reminderSubjects.length === 0 ? (
                <div className="text-center py-6 text-slate-400 text-xs">
                  Chưa có môn học nào được xếp vào Thứ Hai!
                </div>
              ) : (
                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {reminderSubjects.map((sub) => (
                    <div
                      key={sub.id}
                      className="flex items-center justify-between p-2.5 rounded-xl border border-slate-100 hover:border-slate-200 transition-colors bg-slate-50/60"
                    >
                      <div className="flex items-center gap-2.5">
                        <span
                          className="w-2.5 h-2.5 rounded-full shrink-0"
                          style={{ backgroundColor: sub.color }}
                        />
                        <div>
                          <div className="font-bold text-xs sm:text-sm text-slate-800 flex items-center gap-2">
                            <span>{sub.name}</span>
                            <span className="text-[10px] text-slate-500 font-normal">
                              Tiết {sub.periodStart} {sub.periodSpan > 1 ? `- ${sub.periodStart + sub.periodSpan - 1}` : ''}
                            </span>
                          </div>
                          {sub.requiredMaterials && sub.requiredMaterials.length > 0 && (
                            <p className="text-[11px] text-slate-500 line-clamp-1">
                              Mang theo: {sub.requiredMaterials.join(', ')}
                            </p>
                          )}
                        </div>
                      </div>

                      {sub.room && (
                        <span className="text-[11px] text-slate-600 font-medium bg-white px-2 py-0.5 rounded-md border border-slate-200 shrink-0">
                          {sub.room}
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              )}

              <p className="text-[11px] text-slate-400 italic">
                💡 Chuẩn bị sách vở và đồ dùng từ trước giúp bạn có buổi sáng đầu tuần nhẹ nhàng, không vội vã.
              </p>
            </div>
          </div>
        </div>
      ) : (
        /* ==================== WEEKDAY VIEW ==================== */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Today's Subjects & Attendance (Takes 2 cols on lg) */}
          <div className="lg:col-span-2 bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base sm:text-lg font-bold text-slate-800">
                    Lịch Học &amp; Điểm Danh Hôm Nay
                  </h2>
                  <span className="text-xs bg-indigo-50 text-indigo-700 font-bold px-2 py-0.5 rounded-md">
                    {todaySubjects.length} môn
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">{timeGreeting}</p>
              </div>

              {/* Attendance Progress summary */}
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <span className="text-xs font-bold text-slate-700 block">
                    Đã điểm danh: {attendedCount}/{totalTodaySubjects}
                  </span>
                  <div className="w-28 bg-slate-100 h-2 rounded-full overflow-hidden mt-1">
                    <div
                      className="bg-emerald-500 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${attendancePercent}%` }}
                    />
                  </div>
                </div>
                {attendancePercent === 100 && totalTodaySubjects > 0 && (
                  <span className="text-emerald-600 text-xs font-bold bg-emerald-50 p-1.5 rounded-lg">
                    🎉 Xong!
                  </span>
                )}
              </div>
            </div>

            {/* List of today's subjects */}
            {todaySubjects.length === 0 ? (
              <div className="text-center py-10 text-slate-400 space-y-2">
                <BookOpen className="w-10 h-10 mx-auto text-slate-300" />
                <p className="text-sm font-medium">Hôm nay không có môn học nào!</p>
                <button
                  onClick={() => onOpenSubjectModal(currentDay, 1)}
                  className="text-xs text-indigo-600 font-bold hover:underline"
                >
                  + Thêm môn học cho {getDayName(currentDay)}
                </button>
              </div>
            ) : (
              <div className="space-y-2.5 max-h-[460px] overflow-y-auto pr-1">
                {todaySubjects.map((sub) => {
                  const attendanceKey = `${todayDateStr}_${sub.id}`;
                  const isAttended = Boolean(data.attendance[attendanceKey]);
                  const periodDetail = DEFAULT_PERIODS.find((p) => p.number === sub.periodStart);

                  return (
                    <div
                      key={sub.id}
                      className={`relative flex items-center justify-between p-3.5 rounded-2xl border transition-all ${
                        isAttended
                          ? 'bg-emerald-50/40 border-emerald-200'
                          : 'bg-white hover:bg-slate-50/80 border-slate-200'
                      }`}
                    >
                      <div className="flex items-center gap-3.5 min-w-0">
                        {/* Attendance Toggle Button */}
                        <button
                          type="button"
                          onClick={() => handleToggleAttendance(sub.id)}
                          className="shrink-0 p-1 rounded-xl text-slate-400 hover:text-emerald-600 transition-colors"
                          title={isAttended ? 'Hủy điểm danh' : 'Đánh dấu đã học / có mặt'}
                        >
                          {isAttended ? (
                            <CheckCircle2 className="w-6 h-6 text-emerald-600" />
                          ) : (
                            <Circle className="w-6 h-6 text-slate-300 hover:text-slate-400" />
                          )}
                        </button>

                        {/* Subject Details */}
                        <div className="min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span
                              className="w-2.5 h-2.5 rounded-full shrink-0"
                              style={{ backgroundColor: sub.isFreePeriod || sub.name.toLowerCase().includes('trống') ? '#94a3b8' : sub.color }}
                            />
                            <h3
                              className={`text-sm font-bold truncate flex items-center gap-1.5 ${
                                isAttended ? 'line-through text-slate-400' : 'text-slate-800'
                              }`}
                            >
                              {(sub.isFreePeriod || sub.name.toLowerCase().includes('trống')) && <span>☕</span>}
                              <span>{sub.name}</span>
                            </h3>
                            <span className="text-[11px] font-semibold px-2 py-0.5 rounded-md bg-slate-100 text-slate-600">
                              {periodDetail ? periodDetail.label : `Tiết ${sub.periodStart}`}
                              {sub.periodSpan > 1 ? ` (${sub.periodSpan} tiết)` : ''}
                              {periodDetail ? ` • ${periodDetail.startTime}` : ''}
                            </span>
                            {sub.room && (
                              <span className="text-[11px] text-slate-500 bg-slate-50 px-2 py-0.5 rounded-md border border-slate-100">
                                {sub.room}
                              </span>
                            )}
                          </div>

                          {/* Teacher & Required materials list */}
                          <div className="flex items-center gap-3 mt-1 text-xs text-slate-500 flex-wrap">
                            {sub.isFreePeriod || sub.name.toLowerCase().includes('trống') ? (
                              <span className="text-slate-500 font-medium italic">🛋️ Không có ai dạy • Tự học hoặc nghỉ ngơi</span>
                            ) : (
                              sub.teacher && <span>GV: {sub.teacher}</span>
                            )}
                            {sub.requiredMaterials && sub.requiredMaterials.length > 0 && (
                              <span className="text-amber-800 bg-amber-50 px-2 py-0.5 rounded text-[11px] font-medium border border-amber-200">
                                🎒 Cần mang: {sub.requiredMaterials.slice(0, 3).join(', ')}
                                {sub.requiredMaterials.length > 3 ? '...' : ''}
                              </span>
                            )}
                          </div>

                          {sub.notes && (
                            <p className="text-[11px] text-indigo-700 bg-indigo-50/80 px-2 py-0.5 rounded mt-1 inline-block">
                              📌 {sub.notes}
                            </p>
                          )}
                        </div>
                      </div>

                      {/* Right indicator */}
                      <div className="shrink-0 pl-2">
                        {isAttended ? (
                          <span className="text-[11px] font-bold text-emerald-700 bg-emerald-100 px-2 py-1 rounded-lg">
                            {sub.isFreePeriod || sub.name.toLowerCase().includes('trống') ? 'Đã xong' : 'Đã học'}
                          </span>
                        ) : (
                          <span className="text-[11px] font-medium text-slate-500 bg-slate-100 px-2 py-1 rounded-lg">
                            {sub.isFreePeriod || sub.name.toLowerCase().includes('trống') ? 'Tiết trống' : 'Chưa học'}
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Right Column: Tomorrow's Reminder & Backpack Prep */}
          <div className="space-y-4">
            {/* Reminder Card */}
            <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-2xl p-5 border border-indigo-100 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800 text-sm">
                      Ngày Mai ({getDayName(tomorrowKey)}) Học Gì?
                    </h3>
                    <p className="text-[11px] text-slate-500">
                      Chủ động chuẩn bị từ hôm nay
                    </p>
                  </div>
                </div>
              </div>

              {reminderSubjects.length === 0 ? (
                <div className="text-center py-6 text-slate-400 text-xs">
                  {getDayName(tomorrowKey)} không có tiết học nào. Bạn được nghỉ ngơi!
                </div>
              ) : (
                <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                  {reminderSubjects.map((sub) => (
                    <div
                      key={sub.id}
                      className="bg-white p-2.5 rounded-xl border border-indigo-100/80 shadow-2xs space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span
                            className="w-2.5 h-2.5 rounded-full"
                            style={{ backgroundColor: sub.color }}
                          />
                          <span className="font-bold text-xs text-slate-800">
                            {sub.name}
                          </span>
                        </div>
                        <span className="text-[10px] font-semibold text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                          Tiết {sub.periodStart}
                        </span>
                      </div>

                      {sub.requiredMaterials && sub.requiredMaterials.length > 0 && (
                        <p className="text-[11px] text-amber-900 bg-amber-50 p-1 rounded font-medium">
                          📚 {sub.requiredMaterials.join(', ')}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {/* Backpack prep CTA */}
              <button
                onClick={() => onOpenBackpackModal(tomorrowKey, false)}
                className="w-full py-2.5 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center justify-center gap-1.5"
              >
                <Backpack className="w-4 h-4" />
                <span>Soạn Balo Cho Ngày Mai</span>
              </button>
            </div>

            {/* Quick tips & encouragement */}
            <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs space-y-2">
              <div className="flex items-center gap-1.5 text-xs font-bold text-amber-600">
                <Flame className="w-4 h-4" />
                <span>Mẹo học tập hiệu quả</span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed font-hand text-base">
                "Soạn đầy đủ sách vở từ tối hôm trước giúp bạn ngủ ngon hơn và tự tin bước vào ngày học mới mà không sợ quên dụng cụ!" ✨
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
