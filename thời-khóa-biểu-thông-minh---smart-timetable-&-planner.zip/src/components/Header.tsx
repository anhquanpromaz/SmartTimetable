import React from 'react';
import { 
  Sparkles, 
  Pencil, 
  Plus, 
  Download, 
  Palette, 
  Backpack, 
  CalendarRange,
  BookMarked,
  RotateCcw,
  GraduationCap
} from 'lucide-react';
import { DayOfWeek, UserProfile } from '../types/timetable';

interface HeaderProps {
  onOpenSubjectModal: () => void;
  onOpenDrawingModal: () => void;
  onOpenDecorateModal: () => void;
  onOpenExportModal: () => void;
  onOpenBackpackModal: () => void;
  onOpenWelcomeModal: () => void;
  onResetAll?: () => void;
  userProfile?: UserProfile;
  daysVisible: DayOfWeek[];
  onChangeDaysVisible: (days: DayOfWeek[]) => void;
  hasDrawing: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenSubjectModal,
  onOpenDrawingModal,
  onOpenDecorateModal,
  onOpenExportModal,
  onOpenBackpackModal,
  onOpenWelcomeModal,
  onResetAll,
  userProfile,
  daysVisible,
  onChangeDaysVisible,
  hasDrawing,
}) => {
  const isWeekendIncluded = daysVisible.includes('sunday');
  const isSaturdayIncluded = daysVisible.includes('saturday');

  const handleToggleSaturday = () => {
    if (isSaturdayIncluded) {
      onChangeDaysVisible(['monday', 'tuesday', 'wednesday', 'thursday', 'friday']);
    } else {
      onChangeDaysVisible(['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday']);
    }
  };

  const handleToggleSunday = () => {
    if (isWeekendIncluded) {
      onChangeDaysVisible(['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday']);
    } else {
      onChangeDaysVisible(['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']);
    }
  };

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-2xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          {/* Logo & App Title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-pink-500 flex items-center justify-center text-white shadow-md shadow-indigo-200">
              <BookMarked className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-slate-900 text-lg tracking-tight">
                  Thời Khóa Biểu
                </span>
                {userProfile?.className ? (
                  <button
                    onClick={onOpenWelcomeModal}
                    className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-indigo-100 hover:bg-indigo-200 text-indigo-800 transition-colors flex items-center gap-1 shadow-2xs"
                    title="Nhấp để đổi thông tin lớp học"
                  >
                    <GraduationCap className="w-3.5 h-3.5" />
                    <span>{userProfile.className}</span>
                  </button>
                ) : (
                  <button
                    onClick={onOpenWelcomeModal}
                    className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-gradient-to-r from-pink-500 to-indigo-500 text-white shadow-2xs hover:opacity-90 transition-opacity"
                  >
                    Chọn Lớp Học
                  </button>
                )}
              </div>
              <p className="text-xs text-slate-500 hidden sm:block">
                Quản lý lịch học, vẽ trang trí, điểm danh &amp; nhắc nhở chuẩn bị sách vở
              </p>
            </div>
          </div>

          {/* Action Toolbar */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Days visibility switchers */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-semibold text-slate-600">
              <button
                type="button"
                onClick={handleToggleSaturday}
                className={`px-2.5 py-1.5 rounded-lg transition-all ${
                  isSaturdayIncluded ? 'bg-white text-indigo-700 shadow-2xs' : 'hover:text-slate-900'
                }`}
              >
                + Thứ 7
              </button>
              <button
                type="button"
                onClick={handleToggleSunday}
                className={`px-2.5 py-1.5 rounded-lg transition-all ${
                  isWeekendIncluded ? 'bg-white text-indigo-700 shadow-2xs' : 'hover:text-slate-900'
                }`}
              >
                + C.Nhật
              </button>
            </div>

            {/* Drawing studio button */}
            <button
              onClick={onOpenDrawingModal}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-pink-50 hover:bg-pink-100 text-pink-700 border border-pink-200 shadow-2xs transition-all relative"
              title="Vẽ doodle, bút dạ quang trang trí trực tiếp lên thời khóa biểu"
            >
              <Pencil className="w-3.5 h-3.5" />
              <span>Vẽ Trang Trí</span>
              {hasDrawing && (
                <span className="w-2 h-2 rounded-full bg-pink-500 absolute top-1 right-1" />
              )}
            </button>

            {/* Decorate button (themes, background photo, stickers) */}
            <button
              onClick={onOpenDecorateModal}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200 shadow-2xs transition-all"
            >
              <Palette className="w-3.5 h-3.5" />
              <span>Đổi Nền / Sticker</span>
            </button>

            {/* Backpack Prep button */}
            <button
              onClick={onOpenBackpackModal}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 shadow-2xs transition-all"
            >
              <Backpack className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Soạn Balo</span>
              <span className="sm:hidden">Balo</span>
            </button>

            {/* Export & Save button */}
            <button
              onClick={onOpenExportModal}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 transition-all"
              title="Tải ảnh PNG hoặc sao lưu file JSON"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Xuất TKB</span>
            </button>

            {/* Add Subject Primary button */}
            <button
              onClick={onOpenSubjectModal}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm shadow-indigo-200 transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Thêm Môn</span>
            </button>

            {/* Reset All button */}
            {onResetAll && (
              <button
                type="button"
                onClick={onResetAll}
                className="p-2 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                title="Bắt đầu lại từ đầu (Xóa hết dữ liệu cũ)"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
