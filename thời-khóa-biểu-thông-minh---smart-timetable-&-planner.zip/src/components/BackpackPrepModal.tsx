import React, { useState } from 'react';
import { X, CheckCircle2, Circle, Backpack, Sparkles, Plus, AlertCircle } from 'lucide-react';
import confetti from 'canvas-confetti';
import { SubjectItem, DayOfWeek } from '../types/timetable';
import { getDayName } from '../utils/dateHelper';

interface BackpackPrepModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetDay: DayOfWeek;
  subjects: SubjectItem[];
  backpackChecklist: Record<string, boolean>;
  onToggleChecklist: (key: string) => void;
  onAddCustomItem?: (item: string) => void;
  isForNextWeek?: boolean;
}

export const BackpackPrepModal: React.FC<BackpackPrepModalProps> = ({
  isOpen,
  onClose,
  targetDay,
  subjects,
  backpackChecklist,
  onToggleChecklist,
  isForNextWeek = false,
}) => {
  const [customInput, setCustomInput] = useState('');
  const [extraItems, setExtraItems] = useState<string[]>([]);

  if (!isOpen) return null;

  // Collect materials from subjects
  const subjectMaterialsMap: { subjectName: string; color: string; materials: string[] }[] = [];
  subjects.forEach((sub) => {
    if (sub.requiredMaterials && sub.requiredMaterials.length > 0) {
      subjectMaterialsMap.push({
        subjectName: sub.name,
        color: sub.color,
        materials: sub.requiredMaterials,
      });
    } else {
      // Default fallback
      subjectMaterialsMap.push({
        subjectName: sub.name,
        color: sub.color,
        materials: [`SGK & Vở ghi ${sub.name}`],
      });
    }
  });

  // Calculate total items and completed items
  let totalItemsCount = 0;
  let completedItemsCount = 0;

  subjectMaterialsMap.forEach((group) => {
    group.materials.forEach((mat) => {
      totalItemsCount++;
      const key = `${targetDay}_${mat}`;
      if (backpackChecklist[key]) {
        completedItemsCount++;
      }
    });
  });

  extraItems.forEach((mat) => {
    totalItemsCount++;
    const key = `${targetDay}_${mat}`;
    if (backpackChecklist[key]) {
      completedItemsCount++;
    }
  });

  const progressPercent = totalItemsCount > 0 ? Math.round((completedItemsCount / totalItemsCount) * 100) : 0;

  const handleToggle = (material: string) => {
    const key = `${targetDay}_${material}`;
    const nextState = !backpackChecklist[key];
    onToggleChecklist(key);

    // If this completed everything, throw confetti!
    if (nextState && completedItemsCount + 1 === totalItemsCount) {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });
    }
  };

  const handleAddCustom = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = customInput.trim();
    if (trimmed && !extraItems.includes(trimmed)) {
      setExtraItems([...extraItems, trimmed]);
      setCustomInput('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-xl bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-200 my-8">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center shadow-inner">
              <Backpack className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold flex items-center gap-2">
                <span>Soạn Sách Vở Cho {getDayName(targetDay)}</span>
                {isForNextWeek && (
                  <span className="text-[11px] bg-white/25 px-2 py-0.5 rounded-full font-semibold">
                    Tuần Tới
                  </span>
                )}
              </h2>
              <p className="text-xs text-white/90">
                {subjects.length} môn học • Chuẩn bị chu đáo, tự tin đến lớp!
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-white/80 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Progress bar */}
        <div className="bg-amber-50 px-6 py-3 border-b border-amber-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-amber-900">
              Tiến độ soạn balo:
            </span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-amber-200/70 text-amber-900">
              {completedItemsCount} / {totalItemsCount} món ({progressPercent}%)
            </span>
          </div>

          {progressPercent === 100 && totalItemsCount > 0 && (
            <span className="text-xs font-bold text-emerald-700 flex items-center gap-1">
              <Sparkles className="w-4 h-4 text-emerald-600" />
              Đã soạn xong toàn bộ! 🎉
            </span>
          )}
        </div>

        <div className="w-full bg-amber-100 h-1.5">
          <div
            className="bg-emerald-500 h-1.5 transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* Checklist Content */}
        <div className="p-6 space-y-5 max-h-[60vh] overflow-y-auto">
          {subjects.length === 0 ? (
            <div className="text-center py-8 text-slate-400 space-y-2">
              <AlertCircle className="w-10 h-10 mx-auto text-slate-300" />
              <p className="text-sm font-medium">
                {getDayName(targetDay)} không có tiết học nào trên thời khóa biểu!
              </p>
              <p className="text-xs">Bạn có thể thoải mái nghỉ ngơi hoặc ôn tập tự do.</p>
            </div>
          ) : (
            subjectMaterialsMap.map((group, gIdx) => (
              <div key={gIdx} className="space-y-2">
                <div className="flex items-center gap-2">
                  <span
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: group.color }}
                  />
                  <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wide">
                    Môn {group.subjectName}
                  </h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pl-4">
                  {group.materials.map((mat, mIdx) => {
                    const key = `${targetDay}_${mat}`;
                    const isChecked = Boolean(backpackChecklist[key]);
                    return (
                      <button
                        key={mIdx}
                        type="button"
                        onClick={() => handleToggle(mat)}
                        className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-left text-xs transition-all ${
                          isChecked
                            ? 'bg-emerald-50/80 border-emerald-300 text-emerald-900 font-medium'
                            : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-700'
                        }`}
                      >
                        {isChecked ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                        ) : (
                          <Circle className="w-4 h-4 text-slate-300 shrink-0" />
                        )}
                        <span className={isChecked ? 'line-through text-slate-400' : ''}>
                          {mat}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            ))
          )}

          {/* Extra items (if user added custom items) */}
          {extraItems.length > 0 && (
            <div className="space-y-2 pt-2 border-t border-slate-100">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wide">
                Đồ dùng tự chọn thêm
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pl-2">
                {extraItems.map((item, idx) => {
                  const key = `${targetDay}_${item}`;
                  const isChecked = Boolean(backpackChecklist[key]);
                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleToggle(item)}
                      className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-left text-xs transition-all ${
                        isChecked
                          ? 'bg-emerald-50/80 border-emerald-300 text-emerald-900 font-medium'
                          : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-700'
                      }`}
                    >
                      {isChecked ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      ) : (
                        <Circle className="w-4 h-4 text-slate-300 shrink-0" />
                      )}
                      <span className={isChecked ? 'line-through text-slate-400' : ''}>
                        {item}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Add custom item form */}
          <form onSubmit={handleAddCustom} className="pt-2 border-t border-slate-100 flex gap-2">
            <input
              type="text"
              placeholder="Thêm đồ dùng khác (VD: Bình nước, Thẻ học sinh, Tiền ăn...)"
              value={customInput}
              onChange={(e) => setCustomInput(e.target.value)}
              className="flex-1 px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500"
            />
            <button
              type="submit"
              className="px-3.5 py-2 bg-orange-500 hover:bg-orange-600 text-white rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Thêm</span>
            </button>
          </form>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-3.5 border-t border-slate-200 bg-slate-50">
          <p className="text-[11px] text-slate-500">
            Dữ liệu soạn bài được lưu tự động trên máy của bạn.
          </p>
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs sm:text-sm font-semibold bg-slate-800 hover:bg-slate-900 text-white rounded-xl shadow-xs transition-colors"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
};
