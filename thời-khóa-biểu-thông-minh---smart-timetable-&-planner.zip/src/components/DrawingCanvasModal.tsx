import React, { useRef, useState, useEffect } from 'react';
import { 
  Pencil, 
  Eraser, 
  Highlighter, 
  Undo2, 
  Redo2, 
  Trash2, 
  Save, 
  X, 
  Eye, 
  Sparkles,
  Palette
} from 'lucide-react';

interface DrawingCanvasModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentDrawing: string | null;
  onSaveDrawing: (dataUrl: string | null) => void;
  backgroundRef?: HTMLElement | null; // optionally capture reference to show timetable underneath
}

type ToolType = 'pen' | 'highlighter' | 'eraser';

const COLOR_PALETTE = [
  '#ef4444', // Red
  '#f97316', // Orange
  '#f59e0b', // Amber/Yellow
  '#10b981', // Emerald/Green
  '#06b6d4', // Cyan
  '#3b82f6', // Blue
  '#8b5cf6', // Purple
  '#ec4899', // Pink
  '#1e293b', // Dark Slate
  '#ffffff', // White
];

export const DrawingCanvasModal: React.FC<DrawingCanvasModalProps> = ({
  isOpen,
  onClose,
  currentDrawing,
  onSaveDrawing,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [tool, setTool] = useState<ToolType>('pen');
  const [color, setColor] = useState<string>('#ec4899');
  const [lineWidth, setLineWidth] = useState<number>(4);
  const [isDrawing, setIsDrawing] = useState<boolean>(false);
  const [showUnderlay, setShowUnderlay] = useState<boolean>(true);

  // Undo / Redo stacks
  const [history, setHistory] = useState<ImageData[]>([]);
  const [redoList, setRedoList] = useState<ImageData[]>([]);

  useEffect(() => {
    if (!isOpen) return;

    // Small delay to ensure modal DOM is mounted
    const timer = setTimeout(() => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // Set canvas physical resolution
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width;
      canvas.height = rect.height;

      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      // Load existing drawing if available
      if (currentDrawing) {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.onload = () => {
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          // Save initial state
          setHistory([ctx.getImageData(0, 0, canvas.width, canvas.height)]);
        };
        img.src = currentDrawing;
      } else {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        setHistory([ctx.getImageData(0, 0, canvas.width, canvas.height)]);
      }
    }, 50);

    return () => clearTimeout(timer);
  }, [isOpen, currentDrawing]);

  if (!isOpen) return null;

  const pushState = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    setHistory((prev) => [...prev.slice(-15), imgData]); // keep up to 15 steps
    setRedoList([]);
  };

  const handleUndo = () => {
    if (history.length <= 1) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const newHistory = [...history];
    const current = newHistory.pop()!;
    setRedoList((prev) => [...prev, current]);
    const previous = newHistory[newHistory.length - 1];
    setHistory(newHistory);
    ctx.putImageData(previous, 0, 0);
  };

  const handleRedo = () => {
    if (redoList.length === 0) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const newRedo = [...redoList];
    const next = newRedo.pop()!;
    setRedoList(newRedo);
    setHistory((prev) => [...prev, next]);
    ctx.putImageData(next, 0, 0);
  };

  const handleClear = () => {
    if (!confirm('Bạn có chắc muốn xóa toàn bộ nét vẽ này không?')) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    pushState();
  };

  const getCanvasCoords = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    if ('touches' in e) {
      const touch = e.touches[0];
      return {
        x: touch.clientX - rect.left,
        y: touch.clientY - rect.top,
      };
    }
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    };
  };

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    setIsDrawing(true);
    const { x, y } = getCanvasCoords(e);

    ctx.beginPath();
    ctx.moveTo(x, y);

    if (tool === 'eraser') {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.lineWidth = lineWidth * 3;
    } else if (tool === 'highlighter') {
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = color + '66'; // semi-transparent
      ctx.lineWidth = lineWidth * 3.5;
    } else {
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = color;
      ctx.lineWidth = lineWidth;
    }
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { x, y } = getCanvasCoords(e);
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    if (!isDrawing) return;
    setIsDrawing(false);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.closePath();
    pushState();
  };

  const handleSave = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    // Check if canvas is completely empty
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const pixelBuffer = new Uint32Array(
      ctx.getImageData(0, 0, canvas.width, canvas.height).data.buffer
    );
    const hasDrawn = pixelBuffer.some((color) => color !== 0);

    if (!hasDrawn) {
      onSaveDrawing(null);
    } else {
      const dataUrl = canvas.toDataURL('image/png');
      onSaveDrawing(dataUrl);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-2 sm:p-4">
      <div className="relative w-full max-w-5xl h-[92vh] max-h-[850px] bg-white rounded-2xl shadow-2xl flex flex-col overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-100 bg-slate-50/80">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-rose-500 to-indigo-500 flex items-center justify-center text-white shadow-sm">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-slate-800 text-base sm:text-lg flex items-center gap-2">
                Vẽ Trang Trí Thời Khóa Biểu
                <span className="text-xs bg-pink-100 text-pink-700 font-semibold px-2 py-0.5 rounded-full">
                  Doodle &amp; Note
                </span>
              </h2>
              <p className="text-xs text-slate-500 hidden sm:block">
                Tự do vẽ hoa, ngôi sao, ghi chú nhắc nhở hoặc trang trí bảng theo phong cách của bạn!
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowUnderlay(!showUnderlay)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all ${
                showUnderlay
                  ? 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                  : 'bg-slate-100 text-slate-600 border border-slate-200'
              }`}
              title="Ẩn/Hiện đường kẻ lưới để căn chỉnh vẽ"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>{showUnderlay ? 'Lưới mẫu: Bật' : 'Lưới mẫu: Tắt'}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/60 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-2.5 bg-slate-100/80 border-b border-slate-200 text-sm">
          {/* Tool selectors */}
          <div className="flex items-center gap-1.5 bg-white p-1 rounded-xl shadow-xs border border-slate-200/80">
            <button
              onClick={() => setTool('pen')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium text-xs transition-all ${
                tool === 'pen'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Pencil className="w-3.5 h-3.5" />
              <span>Bút vẽ</span>
            </button>

            <button
              onClick={() => setTool('highlighter')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium text-xs transition-all ${
                tool === 'highlighter'
                  ? 'bg-amber-500 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Highlighter className="w-3.5 h-3.5" />
              <span>Dạ quang</span>
            </button>

            <button
              onClick={() => setTool('eraser')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium text-xs transition-all ${
                tool === 'eraser'
                  ? 'bg-rose-500 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Eraser className="w-3.5 h-3.5" />
              <span>Tẩy</span>
            </button>
          </div>

          {/* Color palette */}
          <div className="flex items-center gap-1.5 overflow-x-auto py-1">
            <span className="text-xs text-slate-500 font-medium hidden md:inline flex items-center gap-1">
              <Palette className="w-3.5 h-3.5" /> Màu:
            </span>
            {COLOR_PALETTE.map((c) => (
              <button
                key={c}
                onClick={() => {
                  setColor(c);
                  if (tool === 'eraser') setTool('pen');
                }}
                className={`w-6 h-6 rounded-full border-2 transition-transform ${
                  color === c && tool !== 'eraser' ? 'scale-125 border-slate-800 shadow-sm' : 'border-white'
                }`}
                style={{ backgroundColor: c }}
                title={c}
              />
            ))}
            <input
              type="color"
              value={color}
              onChange={(e) => {
                setColor(e.target.value);
                if (tool === 'eraser') setTool('pen');
              }}
              className="w-7 h-7 rounded-full cursor-pointer border-0 p-0 overflow-hidden bg-transparent"
              title="Chọn màu tự do"
            />
          </div>

          {/* Line width slider */}
          <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-xl border border-slate-200/80">
            <span className="text-xs text-slate-500 font-medium">Nét:</span>
            <input
              type="range"
              min="2"
              max="24"
              value={lineWidth}
              onChange={(e) => setLineWidth(Number(e.target.value))}
              className="w-20 sm:w-28 accent-indigo-600 cursor-pointer h-1.5 bg-slate-200 rounded-lg"
            />
            <span className="text-xs font-mono text-slate-700 w-4">{lineWidth}</span>
          </div>

          {/* Actions: Undo, Redo, Clear */}
          <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-200/80">
            <button
              onClick={handleUndo}
              disabled={history.length <= 1}
              className="p-1.5 rounded-lg text-slate-600 hover:bg-slate-100 disabled:opacity-30 disabled:hover:bg-transparent"
              title="Hoàn tác (Undo)"
            >
              <Undo2 className="w-4 h-4" />
            </button>
            <button
              onClick={handleRedo}
              disabled={redoList.length === 0}
              className="p-1.5 rounded-lg text-slate-600 hover:bg-slate-100 disabled:opacity-30 disabled:hover:bg-transparent"
              title="Làm lại (Redo)"
            >
              <Redo2 className="w-4 h-4" />
            </button>
            <div className="w-px h-4 bg-slate-200 mx-0.5" />
            <button
              onClick={handleClear}
              className="p-1.5 rounded-lg text-rose-600 hover:bg-rose-50"
              title="Xóa trắng bảng vẽ"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Canvas Area */}
        <div className="relative flex-1 bg-slate-200/60 overflow-hidden flex items-center justify-center p-3">
          <div className="relative w-full h-full max-w-4xl bg-white rounded-xl shadow-inner border border-slate-300 overflow-hidden">
            {/* Optional grid background preview to help align with timetable */}
            {showUnderlay && (
              <div 
                className="absolute inset-0 pointer-events-none opacity-25 select-none"
                style={{
                  backgroundImage: `linear-gradient(to right, #cbd5e1 1px, transparent 1px), linear-gradient(to bottom, #cbd5e1 1px, transparent 1px)`,
                  backgroundSize: '40px 40px',
                }}
              >
                <div className="absolute top-2 left-3 text-[11px] font-hand text-slate-400">
                  ✏️ Lưới hỗ trợ vẽ trang trí thời khóa biểu
                </div>
              </div>
            )}

            <canvas
              ref={canvasRef}
              onMouseDown={startDrawing}
              onMouseMove={draw}
              onMouseUp={stopDrawing}
              onMouseLeave={stopDrawing}
              onTouchStart={startDrawing}
              onTouchMove={draw}
              onTouchEnd={stopDrawing}
              className="absolute inset-0 w-full h-full cursor-crosshair touch-none"
            />
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-5 py-3 border-t border-slate-200 bg-white">
          <p className="text-xs text-slate-500 font-hand text-base hidden sm:block">
            Mẹo: Dùng bút dạ quang để đánh dấu các tiết quan trọng hoặc vẽ các biểu tượng may mắn! ⭐🍀
          </p>
          <div className="flex items-center gap-2.5 ml-auto">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs sm:text-sm font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
            >
              Hủy bỏ
            </button>
            <button
              onClick={handleSave}
              className="flex items-center gap-1.5 px-5 py-2 text-xs sm:text-sm font-semibold bg-gradient-to-r from-indigo-600 to-rose-600 hover:from-indigo-700 hover:to-rose-700 text-white rounded-xl shadow-md shadow-indigo-200 hover:shadow-lg transition-all"
            >
              <Save className="w-4 h-4" />
              <span>Lưu Lên Thời Khóa Biểu</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
