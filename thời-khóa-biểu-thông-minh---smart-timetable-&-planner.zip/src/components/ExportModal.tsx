import React, { useRef, useState } from 'react';
import { X, Download, FileJson, Upload, RefreshCw, CheckCircle2, Image as ImageIcon, Trash2 } from 'lucide-react';
import { toPng } from 'html-to-image';
import { TimetableData } from '../types/timetable';
import { exportTimetableJson, importTimetableJson } from '../utils/storage';
import { INITIAL_TIMETABLE_DATA, SAMPLE_SUBJECTS } from '../constants/initialData';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  data: TimetableData;
  timetableRef: React.RefObject<HTMLDivElement | null>;
  onLoadData: (data: TimetableData) => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  data,
  timetableRef,
  onLoadData,
}) => {
  const [isExportingImage, setIsExportingImage] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!isOpen) return null;

  const handleDownloadImage = async () => {
    if (!timetableRef.current) return;
    try {
      setIsExportingImage(true);
      await new Promise((r) => setTimeout(r, 100));

      const dataUrl = await toPng(timetableRef.current, {
        cacheBust: true,
        quality: 0.95,
        pixelRatio: 2,
      });

      const link = document.createElement('a');
      link.download = `thoi-khoa-bieu-${new Date().toISOString().slice(0, 10)}.png`;
      link.href = dataUrl;
      link.click();

      setSuccessMessage('Đã tải ảnh thời khóa biểu thành công!');
      setTimeout(() => setSuccessMessage(null), 3500);
    } catch (err) {
      console.error('Failed to export image:', err);
      alert('Không thể xuất ảnh thời khóa biểu. Vui lòng thử lại!');
    } finally {
      setIsExportingImage(false);
    }
  };

  const handleExportJson = () => {
    exportTimetableJson(data);
    setSuccessMessage('Đã tải file sao lưu JSON về máy!');
    setTimeout(() => setSuccessMessage(null), 3500);
  };

  const handleImportFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const parsedData = await importTimetableJson(file);
      onLoadData(parsedData);
      setSuccessMessage('Khôi phục thời khóa biểu từ file thành công!');
      setTimeout(() => {
        setSuccessMessage(null);
        onClose();
      }, 1500);
    } catch (err: any) {
      alert(`Lỗi nhập file: ${err.message || 'File không đúng định dạng'}`);
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleResetSampleData = () => {
    if (confirm('Bạn có chắc muốn nạp dữ liệu thời khóa biểu mẫu để tham khảo không?')) {
      onLoadData({
        ...data,
        subjects: SAMPLE_SUBJECTS,
      });
      setSuccessMessage('Đã nạp thời khóa biểu mẫu tham khảo thành công!');
      setTimeout(() => {
        setSuccessMessage(null);
        onClose();
      }, 1500);
    }
  };

  const handleClearAllSubjects = () => {
    if (confirm('Bạn có chắc muốn xóa toàn bộ môn học để tạo mới từ đầu không?')) {
      onLoadData({
        ...data,
        subjects: [],
        attendance: {},
      });
      setSuccessMessage('Đã xóa trắng thời khóa biểu!');
      setTimeout(() => {
        setSuccessMessage(null);
        onClose();
      }, 1500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-200 my-8">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
          <div className="flex items-center gap-2.5">
            <Download className="w-5 h-5 text-indigo-400" />
            <div>
              <h2 className="text-base sm:text-lg font-bold">Xuất &amp; Sao Lưu Thời Khóa Biểu</h2>
              <p className="text-xs text-slate-400">Tải ảnh chất lượng cao hoặc sao lưu dữ liệu</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Message toast */}
        {successMessage && (
          <div className="bg-emerald-50 text-emerald-800 border-b border-emerald-200 px-6 py-2.5 text-xs font-semibold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{successMessage}</span>
          </div>
        )}

        <div className="p-6 space-y-4">
          {/* Export PNG */}
          <div className="p-4 rounded-xl border border-indigo-100 bg-indigo-50/50 hover:bg-indigo-50 transition-colors flex items-center justify-between gap-3">
            <div className="space-y-0.5">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-indigo-600" />
                <span>Tải ảnh PNG thời khóa biểu</span>
              </h3>
              <p className="text-xs text-slate-500">
                Xuất ảnh sắc nét để in ra giấy hoặc cài làm hình nền máy tính, điện thoại
              </p>
            </div>
            <button
              onClick={handleDownloadImage}
              disabled={isExportingImage}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors shrink-0 flex items-center gap-1.5"
            >
              {isExportingImage ? 'Đang tạo ảnh...' : 'Tải Về Ảnh'}
            </button>
          </div>

          {/* Backup JSON */}
          <div className="p-4 rounded-xl border border-slate-200 hover:bg-slate-50 transition-colors flex items-center justify-between gap-3">
            <div className="space-y-0.5">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <FileJson className="w-4 h-4 text-amber-600" />
                <span>Sao lưu dữ liệu (File .JSON)</span>
              </h3>
              <p className="text-xs text-slate-500">
                Lưu toàn bộ môn học, hình vẽ và trang trí thành file để chuyển sang máy khác
              </p>
            </div>
            <button
              onClick={handleExportJson}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors shrink-0 flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Tải File</span>
            </button>
          </div>

          {/* Restore JSON */}
          <div className="p-4 rounded-xl border border-slate-200 hover:bg-slate-50 transition-colors flex items-center justify-between gap-3">
            <div className="space-y-0.5">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Upload className="w-4 h-4 text-emerald-600" />
                <span>Khôi phục từ file JSON</span>
              </h3>
              <p className="text-xs text-slate-500">
                Nạp lại thời khóa biểu đã sao lưu trước đó
              </p>
            </div>
            <label className="cursor-pointer px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors shrink-0 flex items-center gap-1.5">
              <Upload className="w-3.5 h-3.5" />
              <span>Chọn File</span>
              <input
                ref={fileInputRef}
                type="file"
                accept=".json"
                onChange={handleImportFile}
                className="hidden"
              />
            </label>
          </div>

          {/* Reset to Sample Data */}
          <div className="p-4 rounded-xl border border-slate-200 hover:bg-slate-50 transition-colors flex items-center justify-between gap-3">
            <div className="space-y-0.5">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <RefreshCw className="w-4 h-4 text-rose-600" />
                <span>Nạp Thời Khóa Biểu Mẫu Chuẩn</span>
              </h3>
              <p className="text-xs text-slate-500">
                Lập tức khôi phục thời khóa biểu mẫu đầy đủ các môn học và dụng cụ
              </p>
            </div>
            <button
              onClick={handleResetSampleData}
              className="px-4 py-2 bg-slate-100 hover:bg-indigo-50 text-slate-700 hover:text-indigo-700 text-xs font-semibold rounded-xl border border-slate-200 transition-colors shrink-0"
            >
              Nạp Mẫu
            </button>
          </div>

          {/* Clear All Subjects */}
          <div className="p-4 rounded-xl border border-slate-200 hover:bg-slate-50 transition-colors flex items-center justify-between gap-3">
            <div className="space-y-0.5">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Trash2 className="w-4 h-4 text-rose-500" />
                <span>Xóa trắng thời khóa biểu</span>
              </h3>
              <p className="text-xs text-slate-500">
                Xóa tất cả các môn học hiện có để bạn tự lập lại thời khóa biểu mới
              </p>
            </div>
            <button
              onClick={handleClearAllSubjects}
              className="px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-semibold rounded-xl border border-rose-200 transition-colors shrink-0"
            >
              Xóa Trắng
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end px-6 py-3.5 border-t border-slate-200 bg-slate-50">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs sm:text-sm font-semibold bg-slate-800 hover:bg-slate-900 text-white rounded-xl shadow-xs transition-colors"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
};
