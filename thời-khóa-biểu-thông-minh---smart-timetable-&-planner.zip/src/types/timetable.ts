export type DayOfWeek = 'monday' | 'tuesday' | 'wednesday' | 'thursday' | 'friday' | 'saturday' | 'sunday';

export interface UserProfile {
  className: string; // e.g. "Lớp 10A1"
  studentName?: string;
  homeroomTeacher?: string; // Giáo viên chủ nhiệm
  subjectTeachers?: Record<string, string>; // Danh sách giáo viên từng môn { "Toán Học": "Cô Mai", ... }
  schoolName?: string;
  hasCompletedWelcome: boolean;
}

export interface SubjectItem {
  id: string;
  name: string;
  code?: string;
  teacher?: string;
  room?: string;
  day: DayOfWeek;
  periodStart: number; // 1 to 7 (1-4 morning, 5-7 afternoon)
  periodSpan: number; // 1, 2...
  session: 'morning' | 'afternoon';
  color: string;
  textColor?: string;
  notes?: string;
  requiredMaterials: string[];
  homework?: string;
  isFreePeriod?: boolean; // Tiết trống (không có ai dạy, tự học hoặc nghỉ)
}

export interface PeriodInfo {
  number: number; // 1-7
  label: string; // "Tiết 1" or "Tiết 1 Chiều"
  displayOrder: number;
  startTime: string;
  endTime: string;
  session: 'morning' | 'afternoon';
}

export interface TimetableSticker {
  id: string;
  content: string;
  type: 'emoji' | 'image';
  x: number;
  y: number;
  size: number;
  rotation: number;
}

export interface TimetableDecoration {
  title: string;
  subtitle: string;
  backgroundImage: string | null;
  backgroundOpacity: number;
  theme: 'pastel' | 'sakura' | 'ocean' | 'mint' | 'sunset' | 'chalkboard';
  drawingDataUrl: string | null;
  stickers: TimetableSticker[];
}

export interface TimetableData {
  userProfile?: UserProfile;
  subjects: SubjectItem[];
  decoration: TimetableDecoration;
  attendance: Record<string, boolean>;
  backpackChecklist: Record<string, boolean>;
  daysVisible: DayOfWeek[];
}

