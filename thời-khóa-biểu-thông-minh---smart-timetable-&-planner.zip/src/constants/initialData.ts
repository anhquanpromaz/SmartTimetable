import { DayOfWeek, PeriodInfo, SubjectItem, TimetableData, UserProfile } from '../types/timetable';

export const DAYS_OF_WEEK: { key: DayOfWeek; name: string; shortName: string; dayIndex: number }[] = [
  { key: 'monday', name: 'Thứ Hai', shortName: 'T2', dayIndex: 1 },
  { key: 'tuesday', name: 'Thứ Ba', shortName: 'T3', dayIndex: 2 },
  { key: 'wednesday', name: 'Thứ Tư', shortName: 'T4', dayIndex: 3 },
  { key: 'thursday', name: 'Thứ Năm', shortName: 'T5', dayIndex: 4 },
  { key: 'friday', name: 'Thứ Sáu', shortName: 'T6', dayIndex: 5 },
  { key: 'saturday', name: 'Thứ Bảy', shortName: 'T7', dayIndex: 6 },
  { key: 'sunday', name: 'Chủ Nhật', shortName: 'CN', dayIndex: 0 },
];

/**
 * Standard School Timetable Periods:
 * Buổi Sáng:
 *  - Tiết 1 (07:00 - 07:45)
 *  - Tiết 2 (07:50 - 08:35)
 *  - [RA CHƠI] (08:35 - 09:00)
 *  - Tiết 3 (09:00 - 09:45)
 *  - Tiết 4 (09:50 - 10:35)
 *  - [RA VỀ HOẶC NGHỈ TRƯA] (10:35 - 13:30)
 *
 * Buổi Chiều:
 *  - Tiết 1 Chiều (13:30 - 14:15)
 *  - Tiết 2 Chiều (14:20 - 15:05)
 *  - [RA CHƠI] (15:05 - 15:25)
 *  - Tiết 3 Chiều (15:25 - 16:10)
 *  - [RA VỀ] (16:10)
 */
export const DEFAULT_PERIODS: PeriodInfo[] = [
  // Buổi Sáng
  { number: 1, label: 'Tiết 1', displayOrder: 1, startTime: '07:00', endTime: '07:45', session: 'morning' },
  { number: 2, label: 'Tiết 2', displayOrder: 2, startTime: '07:50', endTime: '08:35', session: 'morning' },
  { number: 3, label: 'Tiết 3', displayOrder: 3, startTime: '09:00', endTime: '09:45', session: 'morning' },
  { number: 4, label: 'Tiết 4', displayOrder: 4, startTime: '09:50', endTime: '10:35', session: 'morning' },

  // Buổi Chiều
  { number: 5, label: 'Tiết 1 (Chiều)', displayOrder: 5, startTime: '13:30', endTime: '14:15', session: 'afternoon' },
  { number: 6, label: 'Tiết 2 (Chiều)', displayOrder: 6, startTime: '14:20', endTime: '15:05', session: 'afternoon' },
  { number: 7, label: 'Tiết 3 (Chiều)', displayOrder: 7, startTime: '15:25', endTime: '16:10', session: 'afternoon' },
];

export interface SubjectPreset {
  name: string;
  defaultColor: string;
  defaultMaterials: string[];
  icon: string;
}

export const SUBJECT_PRESETS: SubjectPreset[] = [
  {
    name: 'Toán Học',
    defaultColor: '#3b82f6',
    defaultMaterials: ['SGK Toán', 'Vở ghi & Vở bài tập', 'Máy tính Casio fx-580', 'Bộ thước kẻ, compa, êke'],
    icon: '📐',
  },
  {
    name: 'Ngữ Văn',
    defaultColor: '#ec4899',
    defaultMaterials: ['SGK Ngữ Văn', 'Vở soạn văn', 'Vở ghi bài', 'Bút dạ quang highlight'],
    icon: '📖',
  },
  {
    name: 'Tiếng Anh',
    defaultColor: '#10b981',
    defaultMaterials: ['SGK English & Workbook', 'Sổ tay từ vựng', 'Tai nghe học phát âm', 'Bút đỏ sửa bài'],
    icon: '🇬🇧',
  },
  {
    name: 'Vật Lý',
    defaultColor: '#8b5cf6',
    defaultMaterials: ['SGK Vật Lý', 'Vở bài tập Lý', 'Máy tính bỏ túi', 'Thước kẻ 20cm'],
    icon: '⚡',
  },
  {
    name: 'Hóa Học',
    defaultColor: '#06b6d4',
    defaultMaterials: ['SGK Hóa Học', 'Bảng tuần hoàn các nguyên tố hóa học', 'Vở bài tập Hóa', 'Máy tính'],
    icon: '🧪',
  },
  {
    name: 'Sinh Học',
    defaultColor: '#84cc16',
    defaultMaterials: ['SGK Sinh Học', 'Vở ghi Sinh', 'Tài liệu thực hành sơ đồ tư duy'],
    icon: '🧬',
  },
  {
    name: 'Lịch Sử',
    defaultColor: '#f59e0b',
    defaultMaterials: ['SGK Lịch Sử', 'Tập bản đồ Lịch sử', 'Vở ghi niên biểu sự kiện'],
    icon: '🏛️',
  },
  {
    name: 'Địa Lý',
    defaultColor: '#14b8a6',
    defaultMaterials: ['SGK Địa Lý', 'Atlat Địa lí Việt Nam', 'Vở thực hành vẽ biểu đồ', 'Thước kẻ & bút màu'],
    icon: '🌍',
  },
  {
    name: 'Tin Học',
    defaultColor: '#6366f1',
    defaultMaterials: ['SGK Tin Học', 'USB lưu trữ bài tập / Mã nguồn', 'Sổ tay ghi cú pháp'],
    icon: '💻',
  },
  {
    name: 'Giáo Dục Công Dân',
    defaultColor: '#f97316',
    defaultMaterials: ['SGK GDCD / KT-PL', 'Vở ghi tình huống pháp luật'],
    icon: '⚖️',
  },
  {
    name: 'Thể Dục',
    defaultColor: '#ef4444',
    defaultMaterials: ['Đồng phục thể thao', 'Giày bata / Giày thể thao', 'Bình nước cá nhân', 'Khăn lau mồ hôi'],
    icon: '⚽',
  },
  {
    name: 'Công Nghệ',
    defaultColor: '#64748b',
    defaultMaterials: ['SGK Công Nghệ', 'Dụng cụ thực hành kỹ thuật / mô hình'],
    icon: '⚙️',
  },
  {
    name: 'Mỹ Thuật',
    defaultColor: '#d946ef',
    defaultMaterials: ['Hộp màu vẽ (sáp/nước)', 'Bút chì 2B/4B & Gôm tẩy', 'Giấy vẽ A3/A4'],
    icon: '🎨',
  },
  {
    name: 'Âm Nhạc',
    defaultColor: '#a855f7',
    defaultMaterials: ['Tập chép nhạc', 'Thanh phách / Nhạc cụ cá nhân', 'SGK Âm Nhạc'],
    icon: '🎵',
  },
  {
    name: 'Hoạt Động Trải Nghiệm',
    defaultColor: '#0ea5e9',
    defaultMaterials: ['Sổ tay nhật ký hoạt động', 'Bút ghi chú nhóm'],
    icon: '🌟',
  },
  {
    name: 'Chào Cờ / Sinh Hoạt',
    defaultColor: '#e11d48',
    defaultMaterials: ['Đồng phục chỉnh tề, khăn quàng / thẻ học sinh', 'Sổ ghi chép chi đoàn / lớp'],
    icon: '🚩',
  },
  {
    name: 'Tiết Trống (Nghỉ/Tự Học)',
    defaultColor: '#94a3b8',
    defaultMaterials: ['Sách đọc thêm hoặc bài tập tự ôn tập (tự do)'],
    icon: '☕',
  },
];

export const COMMON_TEACHER_SUBJECTS = [
  'Toán Học',
  'Ngữ Văn',
  'Tiếng Anh',
  'Vật Lý',
  'Hóa Học',
  'Sinh Học',
  'Lịch Sử',
  'Địa Lý',
  'Tin Học',
  'Giáo Dục Công Dân',
  'Thể Dục',
  'Công Nghệ',
  'Mỹ Thuật',
  'Âm Nhạc',
];

export const PALETTE_COLORS = [
  '#3b82f6', // Blue
  '#ec4899', // Pink
  '#10b981', // Emerald
  '#8b5cf6', // Violet
  '#f59e0b', // Amber
  '#06b6d4', // Cyan
  '#84cc16', // Lime
  '#f97316', // Orange
  '#6366f1', // Indigo
  '#ef4444', // Red
  '#14b8a6', // Teal
  '#d946ef', // Fuchsia
  '#64748b', // Slate
  '#e11d48', // Rose
];

export const STICKER_LIBRARY = [
  '⭐', '✨', '🌸', '☕', '📚', '🎒', '✏️', '🏆', 
  '💡', '🍀', '🎯', '🐱', '🐶', '🍕', '🍰', '🌱',
  '🎧', '⏰', '🌈', '💯', '🔥', '💖', '🚀', '🎨'
];

export const THEMES = [
  { id: 'pastel', name: 'Kẹo Ngọt Pastel', bgGradient: 'from-amber-50 via-rose-50 to-indigo-50', cardBg: 'bg-white/85' },
  { id: 'sakura', name: 'Hoa Anh Đào', bgGradient: 'from-pink-50 via-rose-100/60 to-purple-50', cardBg: 'bg-white/90' },
  { id: 'mint', name: 'Bạc Hà Thanh Mát', bgGradient: 'from-emerald-50 via-teal-50 to-cyan-50', cardBg: 'bg-white/90' },
  { id: 'ocean', name: 'Biển Xanh Dịu Mát', bgGradient: 'from-blue-50 via-sky-100/70 to-indigo-100/50', cardBg: 'bg-white/90' },
  { id: 'sunset', name: 'Hoàng Hôn Ấm Áp', bgGradient: 'from-amber-100/60 via-orange-50 to-rose-100/50', cardBg: 'bg-white/90' },
  { id: 'chalkboard', name: 'Bảng Đen Học Đường', bgGradient: 'from-slate-900 via-emerald-950 to-slate-900', cardBg: 'bg-slate-800/90', isDark: true },
];

export const WEEKEND_WISHES = [
  'Chúc bạn một ngày nghỉ cuối tuần thật vui vẻ, thư giãn và tràn đầy năng lượng tươi mới! 🎈🌸',
  'Cuối tuần rồi! Tạm gác lại sách vở, hãy tự thưởng cho mình những giây phút nghỉ ngơi thật sảng khoái nhé! ☕🍰',
  'Chúc bạn có một kỳ nghỉ cuối tuần hạnh phúc bên gia đình và bạn bè, nạp lại 100% năng lượng cho tuần mới! ☀️✨',
  'Tận hưởng ngày cuối tuần tuyệt vời! Một tuần vừa qua bạn đã học tập rất chăm chỉ rồi đấy! 🌟🎉',
  'Thư giãn, ngủ một giấc thật ngon và làm những điều mình yêu thích nhé! Chúc bạn cuối tuần thật nhiều niềm vui! 🍀🌈',
];

export const WEEKDAY_GREETINGS = {
  morning: 'Chào buổi sáng rực rỡ! Chúc bạn một ngày học tập hứng khởi, tiếp thu thật nhiều kiến thức mới! ☀️✏️',
  afternoon: 'Chào buổi chiều năng động! Hãy giữ tinh thần tỉnh táo và hoàn thành thật tốt các tiết học nhé! 🍃💪',
  evening: 'Buổi tối ấm áp! Đừng quên kiểm tra lại bài vở và chuẩn bị đầy đủ sách vở cho ngày mai nhé! 🌙📚',
};

export const GRADE_PRESETS = [
  { level: 'Cấp 1 (Tiểu học)', grades: ['Lớp 1', 'Lớp 2', 'Lớp 3', 'Lớp 4', 'Lớp 5'] },
  { level: 'Cấp 2 (THCS)', grades: ['Lớp 6', 'Lớp 7', 'Lớp 8', 'Lớp 9'] },
  { level: 'Cấp 3 (THPT)', grades: ['Lớp 10', 'Lớp 11', 'Lớp 12'] },
  { level: 'Đại Học / Khác', grades: ['Sinh Viên Đại Học', 'Học Cao Đẳng', 'Tự Do'] },
];

/**
 * Empty timetable by default so user creates their own schedule!
 */
export const INITIAL_TIMETABLE_DATA: TimetableData = {
  userProfile: {
    className: '',
    studentName: '',
    homeroomTeacher: '',
    subjectTeachers: {},
    hasCompletedWelcome: false,
  },
  decoration: {
    title: 'Thời Khóa Biểu Của Tôi',
    subtitle: 'Năm Học Mới • Chăm Chỉ & Tự Tin',
    backgroundImage: null,
    backgroundOpacity: 0.15,
    theme: 'pastel',
    drawingDataUrl: null,
    stickers: [],
  },
  daysVisible: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'],
  attendance: {},
  backpackChecklist: {},
  subjects: [], // EMPTY by default
};

/**
 * Optional sample subjects (only loaded if user explicitly chooses to load sample)
 */
export const SAMPLE_SUBJECTS: SubjectItem[] = [
  {
    id: 'sample-1',
    name: 'Chào Cờ / Sinh Hoạt',
    room: 'Sân Trường',
    teacher: 'Thầy Hiệu Trưởng',
    day: 'monday',
    periodStart: 1,
    periodSpan: 1,
    session: 'morning',
    color: '#e11d48',
    requiredMaterials: ['Đồng phục chỉnh tề', 'Khăn quàng đỏ / Thẻ học sinh', 'Sổ ghi chép'],
  },
  {
    id: 'sample-2',
    name: 'Toán Học',
    room: 'Phòng 204',
    teacher: 'Cô Mai',
    day: 'monday',
    periodStart: 2,
    periodSpan: 1,
    session: 'morning',
    color: '#3b82f6',
    notes: 'Kiểm tra bài cũ phần Đại số',
    requiredMaterials: ['SGK Toán', 'Vở bài tập', 'Máy tính Casio fx-580', 'Bộ thước kẻ, compa'],
  },
  {
    id: 'sample-3',
    name: 'Ngữ Văn',
    room: 'Phòng 204',
    teacher: 'Thầy Hưng',
    day: 'monday',
    periodStart: 3,
    periodSpan: 2,
    session: 'morning',
    color: '#ec4899',
    requiredMaterials: ['SGK Ngữ Văn', 'Vở soạn bài tập', 'Bút dạ quang'],
  },
  {
    id: 'sample-4',
    name: 'Tiếng Anh',
    room: 'Phòng Lab 1',
    teacher: 'Ms. Emily',
    day: 'tuesday',
    periodStart: 1,
    periodSpan: 2,
    session: 'morning',
    color: '#10b981',
    requiredMaterials: ['SGK English & Workbook', 'Sổ từ vựng'],
  },
  {
    id: 'sample-5',
    name: 'Vật Lý',
    room: 'Phòng 204',
    teacher: 'Thầy Tuấn',
    day: 'tuesday',
    periodStart: 3,
    periodSpan: 2,
    session: 'morning',
    color: '#8b5cf6',
    requiredMaterials: ['SGK Vật Lý', 'Vở bài tập', 'Máy tính'],
  },
  {
    id: 'sample-6',
    name: 'Tin Học',
    room: 'Phòng Máy 2',
    teacher: 'Thầy Long',
    day: 'tuesday',
    periodStart: 5, // Tiết 1 Chiều
    periodSpan: 2,
    session: 'afternoon',
    color: '#6366f1',
    requiredMaterials: ['SGK Tin Học', 'USB lưu trữ bài tập'],
  },
];
