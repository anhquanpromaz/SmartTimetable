import { TimetableData } from '../types/timetable';
import { INITIAL_TIMETABLE_DATA } from '../constants/initialData';

const STORAGE_KEY = 'smart_timetable_app_v4_clean';

export function loadTimetableData(): TimetableData {
  try {
    // Clear out any obsolete testing data from previous versions
    if (localStorage.getItem('smart_timetable_app_v1')) localStorage.removeItem('smart_timetable_app_v1');
    if (localStorage.getItem('smart_timetable_app_v2')) localStorage.removeItem('smart_timetable_app_v2');
    if (localStorage.getItem('smart_timetable_app_v3')) localStorage.removeItem('smart_timetable_app_v3');

    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return INITIAL_TIMETABLE_DATA;
    }
    const parsed = JSON.parse(raw);
    return {
      ...INITIAL_TIMETABLE_DATA,
      ...parsed,
      decoration: {
        ...INITIAL_TIMETABLE_DATA.decoration,
        ...(parsed.decoration || {}),
      },
    };
  } catch (err) {
    console.error('Failed to parse timetable data from storage:', err);
    return INITIAL_TIMETABLE_DATA;
  }
}

export function clearAllTimetableData(): TimetableData {
  try {
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem('smart_timetable_app_v1');
    localStorage.removeItem('smart_timetable_app_v2');
    localStorage.removeItem('smart_timetable_app_v3');
  } catch (err) {
    console.error('Error clearing local storage:', err);
  }
  return INITIAL_TIMETABLE_DATA;
}

export function saveTimetableData(data: TimetableData): boolean {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    return true;
  } catch (err) {
    console.error('Failed to save timetable data:', err);
    return false;
  }
}

export function exportTimetableJson(data: TimetableData) {
  const jsonStr = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `thoi-khoa-bieu-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

export function importTimetableJson(file: File): Promise<TimetableData> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target?.result as string;
        const parsed = JSON.parse(text);
        if (!parsed.subjects || !Array.isArray(parsed.subjects)) {
          throw new Error('Dữ liệu không hợp lệ: thiếu danh sách môn học');
        }
        resolve(parsed);
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = () => reject(new Error('Không thể đọc file'));
    reader.readAsText(file);
  });
}
