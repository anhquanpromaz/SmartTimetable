import { DayOfWeek, SubjectItem, PeriodInfo } from '../types/timetable';
import { DAYS_OF_WEEK, WEEKEND_WISHES, WEEKDAY_GREETINGS, DEFAULT_PERIODS } from '../constants/initialData';

export function getTodayKey(): DayOfWeek {
  const dayIndex = new Date().getDay(); // 0 is Sunday, 1 is Monday ...
  const found = DAYS_OF_WEEK.find((d) => d.dayIndex === dayIndex);
  return found ? found.key : 'monday';
}

export function getTomorrowKey(todayKey: DayOfWeek): DayOfWeek {
  const index = DAYS_OF_WEEK.findIndex((d) => d.key === todayKey);
  const nextIndex = (index + 1) % DAYS_OF_WEEK.length;
  return DAYS_OF_WEEK[nextIndex].key;
}

export function getDayName(key: DayOfWeek): string {
  const found = DAYS_OF_WEEK.find((d) => d.key === key);
  return found ? found.name : '';
}

export function getFormattedDate(date: Date = new Date()): string {
  const dayNames = ['Chủ Nhật', 'Thứ Hai', 'Thứ Ba', 'Thứ Tư', 'Thứ Năm', 'Thứ Sáu', 'Thứ Bảy'];
  const day = dayNames[date.getDay()];
  const d = String(date.getDate()).padStart(2, '0');
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const y = date.getFullYear();
  return `${day}, ngày ${d}/${m}/${y}`;
}

export function getTodayDateString(date: Date = new Date()): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function isWeekend(dayKey: DayOfWeek): boolean {
  return dayKey === 'saturday' || dayKey === 'sunday';
}

export function getRandomWeekendWish(): string {
  const idx = Math.floor(Math.random() * WEEKEND_WISHES.length);
  return WEEKEND_WISHES[idx];
}

export function getTimeGreeting(hour: number = new Date().getHours()): string {
  if (hour < 12) return WEEKDAY_GREETINGS.morning;
  if (hour < 18) return WEEKDAY_GREETINGS.afternoon;
  return WEEKDAY_GREETINGS.evening;
}

export function getSubjectsForDay(subjects: SubjectItem[], day: DayOfWeek): SubjectItem[] {
  return subjects
    .filter((s) => s.day === day)
    .sort((a, b) => a.periodStart - b.periodStart);
}

export function getPeriodInfo(periodNumber: number, periods: PeriodInfo[] = DEFAULT_PERIODS): PeriodInfo | undefined {
  return periods.find((p) => p.number === periodNumber);
}

// Check if a period is currently ongoing
export function isPeriodActive(period: PeriodInfo): boolean {
  const now = new Date();
  const currentMinutes = now.getHours() * 60 + now.getMinutes();
  
  const [startH, startM] = period.startTime.split(':').map(Number);
  const [endH, endM] = period.endTime.split(':').map(Number);
  
  const startMinutes = startH * 60 + startM;
  const endMinutes = endH * 60 + endM;
  
  return currentMinutes >= startMinutes && currentMinutes <= endMinutes;
}
