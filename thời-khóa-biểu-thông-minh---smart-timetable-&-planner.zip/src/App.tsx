import React, { useState, useEffect, useRef } from 'react';
import { Header } from './components/Header';
import { DailyDashboard } from './components/DailyDashboard';
import { TimetableGrid } from './components/TimetableGrid';
import { SubjectModal } from './components/SubjectModal';
import { DrawingCanvasModal } from './components/DrawingCanvasModal';
import { DecorateModal } from './components/DecorateModal';
import { BackpackPrepModal } from './components/BackpackPrepModal';
import { ExportModal } from './components/ExportModal';
import { WelcomeModal } from './components/WelcomeModal';
import { TimetableData, SubjectItem, DayOfWeek, TimetableDecoration, UserProfile } from './types/timetable';
import { loadTimetableData, saveTimetableData, clearAllTimetableData } from './utils/storage';
import { getTodayKey, getTomorrowKey, isWeekend } from './utils/dateHelper';
import { THEMES } from './constants/initialData';

export default function App() {
  // Load initial data from localStorage or fallback to defaults
  const [data, setData] = useState<TimetableData>(() => loadTimetableData());

  // Welcome modal: open on first time if user hasn't completed welcome yet
  const [isWelcomeModalOpen, setIsWelcomeModalOpen] = useState<boolean>(() => {
    return !data.userProfile?.hasCompletedWelcome;
  });

  // Modal visibility states
  const [isSubjectModalOpen, setIsSubjectModalOpen] = useState(false);
  const [editingSubject, setEditingSubject] = useState<SubjectItem | null>(null);
  const [defaultDayForModal, setDefaultDayForModal] = useState<DayOfWeek>('monday');
  const [defaultPeriodForModal, setDefaultPeriodForModal] = useState<number>(1);

  const [isDrawingModalOpen, setIsDrawingModalOpen] = useState(false);
  const [isDecorateModalOpen, setIsDecorateModalOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);

  // Backpack prep modal
  const [isBackpackModalOpen, setIsBackpackModalOpen] = useState(false);
  const [backpackTargetDay, setBackpackTargetDay] = useState<DayOfWeek>(() => {
    const today = getTodayKey();
    return isWeekend(today) ? 'monday' : getTomorrowKey(today);
  });
  const [isBackpackNextWeek, setIsBackpackNextWeek] = useState(false);

  // Ref to timetable area for export as image
  const timetableRef = useRef<HTMLDivElement | null>(null);

  // Auto-save whenever data changes
  useEffect(() => {
    saveTimetableData(data);
  }, [data]);

  // Reset all data and restart welcome flow
  const handleResetAll = () => {
    if (confirm('Bạn có chắc muốn bắt đầu lại từ đầu và xóa toàn bộ dữ liệu thời khóa biểu không?')) {
      const freshData = clearAllTimetableData();
      setData(freshData);
      setIsWelcomeModalOpen(true);
    }
  };

  // Subject management
  const handleOpenAddSubject = (day: DayOfWeek = 'monday', period: number = 1) => {
    setEditingSubject(null);
    setDefaultDayForModal(day);
    setDefaultPeriodForModal(period);
    setIsSubjectModalOpen(true);
  };

  const handleOpenEditSubject = (subject: SubjectItem) => {
    setEditingSubject(subject);
    setDefaultDayForModal(subject.day);
    setDefaultPeriodForModal(subject.periodStart);
    setIsSubjectModalOpen(true);
  };

  const handleSaveSubject = (savedSubject: SubjectItem) => {
    setData((prev) => {
      const exists = prev.subjects.some((s) => s.id === savedSubject.id);
      let updatedSubjects: SubjectItem[];

      if (exists) {
        updatedSubjects = prev.subjects.map((s) =>
          s.id === savedSubject.id ? savedSubject : s
        );
      } else {
        updatedSubjects = [...prev.subjects, savedSubject];
      }

      return {
        ...prev,
        subjects: updatedSubjects,
      };
    });
  };

  const handleDeleteSubject = (subjectId: string) => {
    setData((prev) => ({
      ...prev,
      subjects: prev.subjects.filter((s) => s.id !== subjectId),
    }));
  };

  // Attendance management
  const handleUpdateAttendance = (attendanceKey: string) => {
    setData((prev) => ({
      ...prev,
      attendance: {
        ...prev.attendance,
        [attendanceKey]: !prev.attendance[attendanceKey],
      },
    }));
  };

  // Backpack checklist management
  const handleToggleBackpackChecklist = (checklistKey: string) => {
    setData((prev) => ({
      ...prev,
      backpackChecklist: {
        ...prev.backpackChecklist,
        [checklistKey]: !prev.backpackChecklist[checklistKey],
      },
    }));
  };

  // Decoration management
  const handleUpdateDecoration = (decoration: TimetableDecoration) => {
    setData((prev) => ({
      ...prev,
      decoration,
    }));
  };

  // Drawing overlay management
  const handleSaveDrawing = (drawingDataUrl: string | null) => {
    setData((prev) => ({
      ...prev,
      decoration: {
        ...prev.decoration,
        drawingDataUrl,
      },
    }));
  };

  // Stickers management
  const handleUpdateStickers = (stickers: any[]) => {
    setData((prev) => ({
      ...prev,
      decoration: {
        ...prev.decoration,
        stickers,
      },
    }));
  };

  // Days visible toggle
  const handleChangeDaysVisible = (days: DayOfWeek[]) => {
    setData((prev) => ({
      ...prev,
      daysVisible: days,
    }));
  };

  // Save user profile from welcome modal
  const handleSaveProfile = (profile: UserProfile, daysVisible: DayOfWeek[], title: string) => {
    setData((prev) => ({
      ...prev,
      userProfile: profile,
      daysVisible,
      decoration: {
        ...prev.decoration,
        title,
        subtitle: profile.className ? `${profile.className} • Năm Học Mới` : prev.decoration.subtitle,
      },
    }));
  };

  // Full data reload (from JSON import or Reset)
  const handleLoadData = (newData: TimetableData) => {
    setData(newData);
  };

  // Open backpack modal with specific target day
  const handleOpenBackpackModalWithDay = (targetDay: DayOfWeek, isNextWeek: boolean = false) => {
    setBackpackTargetDay(targetDay);
    setIsBackpackNextWeek(isNextWeek);
    setIsBackpackModalOpen(true);
  };

  const activeTheme = THEMES.find((t) => t.id === data.decoration.theme) || THEMES[0];

  return (
    <div className={`min-h-screen bg-gradient-to-br ${activeTheme.bgGradient} flex flex-col transition-colors duration-500`}>
      {/* Sticky Header */}
      <Header
        onOpenSubjectModal={() => handleOpenAddSubject(getTodayKey(), 1)}
        onOpenDrawingModal={() => setIsDrawingModalOpen(true)}
        onOpenDecorateModal={() => setIsDecorateModalOpen(true)}
        onOpenExportModal={() => setIsExportModalOpen(true)}
        onOpenBackpackModal={() => handleOpenBackpackModalWithDay(backpackTargetDay, false)}
        onOpenWelcomeModal={() => setIsWelcomeModalOpen(true)}
        onResetAll={handleResetAll}
        userProfile={data.userProfile}
        daysVisible={data.daysVisible}
        onChangeDaysVisible={handleChangeDaysVisible}
        hasDrawing={Boolean(data.decoration.drawingDataUrl)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 space-y-6">
        {/* Daily Dashboard & Greeting / Review / Attendance */}
        <DailyDashboard
          data={data}
          onUpdateAttendance={handleUpdateAttendance}
          onOpenBackpackModal={handleOpenBackpackModalWithDay}
          onOpenSubjectModal={handleOpenAddSubject}
          onOpenDecorateModal={() => setIsDecorateModalOpen(true)}
          onOpenDrawingModal={() => setIsDrawingModalOpen(true)}
        />

        {/* Timetable Interactive Grid */}
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <h2 className="text-sm sm:text-base font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
              <span>Bảng Thời Khóa Biểu Tuần</span>
              <span className="text-xs text-slate-400 font-normal lowercase">
                (nhấp vào ô để thêm môn, nhấp vào môn để chỉnh sửa)
              </span>
            </h2>
            <div className="flex items-center gap-2">
              {data.decoration.drawingDataUrl && (
                <button
                  onClick={() => setIsDrawingModalOpen(true)}
                  className="text-xs text-pink-600 font-semibold hover:underline flex items-center gap-1"
                >
                  ✏️ Đang có hình vẽ trang trí
                </button>
              )}
            </div>
          </div>

          <TimetableGrid
            data={data}
            onSelectSubject={handleOpenEditSubject}
            onAddSubject={handleOpenAddSubject}
            onUpdateStickers={handleUpdateStickers}
            timetableRef={timetableRef}
            onOpenWelcomeModal={() => setIsWelcomeModalOpen(true)}
          />
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-200/60 bg-white/70 backdrop-blur-xs py-4 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p>
            Thời Khóa Biểu Thông Minh • Tự động lưu mọi thay đổi trên trình duyệt của bạn 💾
          </p>
          <div className="flex items-center gap-3 font-medium">
            <button
              onClick={() => setIsDrawingModalOpen(true)}
              className="text-slate-600 hover:text-indigo-600 transition-colors"
            >
              Vẽ trang trí
            </button>
            <span>•</span>
            <button
              onClick={() => setIsDecorateModalOpen(true)}
              className="text-slate-600 hover:text-indigo-600 transition-colors"
            >
              Đổi ảnh nền
            </button>
            <span>•</span>
            <button
              onClick={() => setIsExportModalOpen(true)}
              className="text-slate-600 hover:text-indigo-600 transition-colors"
            >
              Xuất ảnh TKB
            </button>
            <span>•</span>
            <button
              onClick={handleResetAll}
              className="text-rose-500 hover:text-rose-700 transition-colors"
              title="Xóa toàn bộ dữ liệu và bắt đầu lại từ đầu"
            >
              🔄 Bắt đầu lại từ đầu
            </button>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <WelcomeModal
        isOpen={isWelcomeModalOpen}
        onClose={() => setIsWelcomeModalOpen(false)}
        initialProfile={data.userProfile}
        onSaveProfile={handleSaveProfile}
      />

      <SubjectModal
        isOpen={isSubjectModalOpen}
        onClose={() => setIsSubjectModalOpen(false)}
        onSave={handleSaveSubject}
        onDelete={handleDeleteSubject}
        initialSubject={editingSubject}
        defaultDay={defaultDayForModal}
        defaultPeriod={defaultPeriodForModal}
        userProfile={data.userProfile}
      />

      <DrawingCanvasModal
        isOpen={isDrawingModalOpen}
        onClose={() => setIsDrawingModalOpen(false)}
        currentDrawing={data.decoration.drawingDataUrl}
        onSaveDrawing={handleSaveDrawing}
      />

      <DecorateModal
        isOpen={isDecorateModalOpen}
        onClose={() => setIsDecorateModalOpen(false)}
        decoration={data.decoration}
        onUpdateDecoration={handleUpdateDecoration}
        onOpenDrawingModal={() => setIsDrawingModalOpen(true)}
      />

      <BackpackPrepModal
        isOpen={isBackpackModalOpen}
        onClose={() => setIsBackpackModalOpen(false)}
        targetDay={backpackTargetDay}
        subjects={data.subjects.filter((s) => s.day === backpackTargetDay)}
        backpackChecklist={data.backpackChecklist}
        onToggleChecklist={handleToggleBackpackChecklist}
        isForNextWeek={isBackpackNextWeek}
      />

      <ExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        data={data}
        timetableRef={timetableRef}
        onLoadData={handleLoadData}
      />
    </div>
  );
}
